<?php
/**
 * Lost password reset form.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/form-reset-password.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.2.0
 */

defined( 'ABSPATH' ) || exit;
global $zardkooh_options;

if ( isset( $zardkooh_options['logo'] ) && strlen( $zardkooh_options['logo']['url'] ) > 0 ) {
	$logo_href = $zardkooh_options['logo']['url'];
} else {
	$logo_href = get_template_directory_uri().'/assets/images/logo.svg';
}
?>
<div class="account-page-layout">
	<a href="<?php echo home_url('/');?>" class="account-page-logo"><img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo();?>"></a>
	<div class="account-box-main">
		<div class="account-box-top">
			<h3><?php esc_attr_e( 'New Password', 'zardkooh' ); ?></h3>
			<div class="account-box-content">
			
				<?php do_action( 'woocommerce_before_reset_password_form' ); ?>
				
				<form method="post" class="woocommerce-ResetPassword lost_reset_password">

					<p><?php echo apply_filters( 'woocommerce_reset_password_message', esc_html__( 'Enter a new password below.', 'woocommerce' ) ); ?></p><?php // @codingStandardsIgnoreLine ?>

					<p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
						<label for="password_1"><?php esc_html_e( 'New password', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
						<input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password_1" id="password_1" autocomplete="new-password" />
					</p>
					<p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
						<label for="password_2"><?php esc_html_e( 'Re-enter new password', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
						<input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password_2" id="password_2" autocomplete="new-password" />
					</p>

					<input type="hidden" name="reset_key" value="<?php echo esc_attr( $args['key'] ); ?>" />
					<input type="hidden" name="reset_login" value="<?php echo esc_attr( $args['login'] ); ?>" />

					<div class="clear"></div>

					<?php do_action( 'woocommerce_resetpassword_form' ); ?>

					<p class="woocommerce-form-row form-row">
						<input type="hidden" name="wc_reset_password" value="true" />
						<button type="submit" class="woocommerce-Button button<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" value="<?php esc_attr_e( 'Save', 'woocommerce' ); ?>"><?php esc_html_e( 'Save', 'woocommerce' ); ?></button>
					</p>

					<?php wp_nonce_field( 'reset_password', 'woocommerce-reset-password-nonce' ); ?>

				</form>
				
				<?php do_action( 'woocommerce_after_reset_password_form' ); ?>
				
			</div>
		</div>
		<div class="account-box-footer">
			<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" class="btn-link-border"><?php _e ('Login To Site','zardkooh');?></a>
		</div>
	</div>
	<a href="<?php echo home_url('/');?>" class="account-page-return"><?php _e ('Return To Homepage','zardkooh');?></a>
</div>
