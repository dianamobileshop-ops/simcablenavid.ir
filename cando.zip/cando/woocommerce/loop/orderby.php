<?php
/**
 * Show options for ordering
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/orderby.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     9.7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$id_suffix = wp_unique_id();

if ( ! defined( 'YITH_WCAN' ) ) {
	$shop_page_uri	= str_replace('IR','',strtok( ( is_ssl() ? 'https://' : 'http://' ) . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] ));
	$filter_value	= array();
} else {

	$shop_page_uri = yit_get_woocommerce_layered_nav_link();

	$filter_value_args = array(
		'queried_object' => get_queried_object()
	);

	$filter_value = yit_get_filter_args( $filter_value_args );
}
?>

<?php if ( zardkooh_is_mobile() ) { ?>
	<div class="remodal-wrapper">
		<div class="remodal remodal-sort" data-remodal-id="sort-filter" role="dialog" aria-labelledby="modal1Title" aria-describedby="modal1Desc" tabindex="-1" data-remodal-options="hashTracking: false">
			<button data-remodal-action="close" class="remodal-close" aria-label="Close"></button>
			<div class="remodal-sort-header"><?php _e( 'Sort By: ', 'zardkooh' ); ?></div>
			<div class="remodal-sort-content">
				<ul class="remodal-sort-items">
					<?php foreach ( $catalog_orderby_options as $id => $name ) :
						$class = 'orderby-item';
						if ( $orderby == $id ) { 
							$class = 'orderby-item is-active';
							unset($filter_value['orderby'] );
						} else {
							$filter_value['orderby'] = $id;
						}
						echo '<li><a href="' . esc_url( add_query_arg( $filter_value, $shop_page_uri ) ) . '" data-id="' . esc_attr( $id ) .'" class="'.$class.'" >' . esc_html( $name ) . '</a></li>';
					endforeach; ?>
				</ul>
			</div>
		</div>
	</div>
<?php } else { ?>
	<div class="shop-page-header">
		<section id="zardkooh-woo-ajax-navigation-sort-by" class="zardkooh-shop-sort-by yith-wcan-sort-by">
			<div class="sort-by-title"><?php _e( 'Sort By', 'zardkooh' ); ?></div>
			<ul class="shop-page-header-sort">
				<?php foreach ( $catalog_orderby_options as $id => $name ) :
					$class = 'orderby-item';
					if ( $orderby == $id ) { 
						$class = 'orderby-item is-active';
						unset($filter_value['orderby'] );
					} else {
						$filter_value['orderby'] = $id;
					}
					echo '<li><a href="' . esc_url( add_query_arg( $filter_value, $shop_page_uri ) ) . '" data-id="' . esc_attr( $id ) .'" class="'.$class.'" >' . esc_html( $name ) . '</a></li>';
				endforeach; ?>
			</ul>
		</section>
	</div>
<?php } ?>