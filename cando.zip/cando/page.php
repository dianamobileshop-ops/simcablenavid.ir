<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */

get_header(); ?>

<div class="container main-warp">
	<?php while ( have_posts() ) : the_post(); ?>

		<?php if ( is_zardkooh_content_page() ) { the_content(); } else { ?>
		
		<?php zardkooh_breadcrumbs(); ?>
		<main id="main" class="other-pages" role="main">
			
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<section class="other-pages-content">
					<header class="entry-header">
						<?php the_title( '<h1 class="other-pages-title">', '</h1>' ); ?>
					</header><!-- .entry-header -->
					<div class="entry-content">
						<?php
							the_content();

							wp_link_pages( array(
								'before' => '<div class="page-links">' . __( 'Pages:', 'zardkooh' ),
								'after'  => '</div>',
							) );
						?>
					</div><!-- .entry-content -->
				</section>
			</article><!-- #post-## -->
					
			<?php if ( comments_open() || get_comments_number() ) :	comments_template(); endif;	?>

			<?php } ?>
		
		</main><!-- #main -->

	<?php endwhile; // End of the loop.	?>
		
</div><!-- .container main -->

<?php get_footer();
