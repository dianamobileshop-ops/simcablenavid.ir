<?php
/**
 * Cando functions and definitions
 */

require_once ( get_template_directory() . '/include/cando-init.php');

global $zardkooh_options, $login_mobile_meta, $cando_mobile_meta;

$cando_mobile_meta	= 'billing_mobile';
$login_mobile_meta	= 'user_mobile_number';

$zardkooh_options = get_option( 'zardkooh_options' );

if ( isset( $zardkooh_options['cando_login_metakey'] ) && $zardkooh_options['cando_login_metakey'] !== '' ) {
	$login_mobile_meta = $zardkooh_options['cando_login_metakey'];
}

if ( isset( $zardkooh_options['cando_mobile_metakey'] ) && $zardkooh_options['cando_mobile_metakey'] !== '' ) {
	$cando_mobile_meta = $zardkooh_options['cando_mobile_metakey'];
}

if ( !isset( $zardkooh_options['nikikala_login'] ) || !$zardkooh_options['nikikala_login'] ) {
	$login_mobile_meta = $cando_mobile_meta;
}

add_action( 'after_setup_theme', 'zardkooh_setup', 10 );
function zardkooh_setup() {

    load_theme_textdomain( 'zardkooh', trailingslashit(get_template_directory()).'languages' );

	add_theme_support( 'automatic-feed-links' );

	add_theme_support( 'title-tag' );

	add_theme_support( 'post-thumbnails' );

	add_image_size( 'blog-thumb', 58 );

	register_nav_menus( array (
		'main'		=> __( 'Main Menu', 'zardkooh' ),
        'main_mob'	=> __( 'Mobile Main Menu', 'zardkooh' ),
		'top'		=> __( 'Top Menu', 'zardkooh' ),
	));

	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
		'gallery',
		'audio',
	) );

	add_theme_support( 'customize-selective-refresh-widgets' );

	add_theme_support( 'woocommerce' );

}

add_action( 'wp_head', 'zardkooh_javascript_detection', 0 );
function zardkooh_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}

add_action( 'wp_head', 'zardkooh_pingback_header' );
function zardkooh_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">' . "\n", get_bloginfo( 'pingback_url' ) );
	}
}

function rm_query_string( $src ){
    $parts = explode( '?ver', $src );
    return $parts[0];
}
if ( !is_admin() ) {
    add_filter( 'script_loader_src', 'rm_query_string', 15, 1 );
    add_filter( 'style_loader_src', 'rm_query_string', 15, 1 );
}

require_once dirname( __FILE__ ) . '/include/plugins/plugin-activation.php';

add_action( 'tgmpa_register', 'zardkooh_require_plugins' );

function zardkooh_require_plugins() {

    $plugins = array(
        array(
            'name'      => 'Redux Framework',
            'slug'      => 'redux-framework',
            'required'  => true,
        ),
        array(
            'name'      => 'Woocommerce',
            'slug'      => 'woocommerce',
            'required'  => true,
        ),
        array(
            'name'      => 'Persian Woocommerce',
            'slug'      => 'persian-woocommerce',
            'required'  => true,
        ),
        array(
            'name'      => 'Menu Image',
            'slug'      => 'menu-image',
            'required'  => true,
        ),
        array(
            'name'      => 'Elementor',
            'slug'      => 'elementor',
            'required'  => true,
        ),
        array(
            'name'      => 'Contact Form 7',
            'slug'      => 'contact-form-7',
            'required'  => false,
        ),
        array(
            'name'      => 'Variation Swatches for WooCommerce',
            'slug'      => 'woo-variation-swatches',
            'required'  => true,
        ),
		array(
            'name'      => 'QR Code Woocommerce',
            'slug'      => 'qr-code-woocommerce',
            'required'  => false,
        ),
        array(
            'name'               => 'AJAX Search for WooCommerce',
            'slug'               => 'ajax-search-for-woocommerce',
            'source'             => get_stylesheet_directory() . '/include/plugins/ajax-search-for-woocommerce.zip',
            'required'           => true,
            'version'            => '1.32.2',
        ),
		array(
            'name'               => 'WP Rating System',
            'slug'               => 'rate-my-post',
            'source'             => get_stylesheet_directory() . '/include/plugins/rate-my-post.zip',
            'required'           => true,
            'version'            => '4.5.0',
        ),
        array(
            'name'               => 'YITH WooCommerce Brands Add On',
            'slug'               => 'yith-woocommerce-brands-add-on',
            'source'             => get_stylesheet_directory() . '/include/plugins/yith-woocommerce-brands-add-on.zip',
            'required'           => false,
            'version'            => '2.38.0',
        ),
        array(
            'name'               => 'YITH WooCommerce Ajax Product Filter Premium',
            'slug'               => 'yith-woocommerce-ajax-product-filter-premium',
            'source'             => get_stylesheet_directory() . '/include/plugins/yith-woocommerce-ajax-product-filter-premium.zip',
            'required'           => true,
            'version'            => '5.17.0',
        ),
    );

    $config = array( /* The array to configure TGM Plugin Activation */ );

    tgmpa( $plugins, $config );
}
add_action( 'init', function() {
    $url = $_SERVER['REQUEST_URI'] ?? '';
    
    // اگر درخواست برای لینک کاربران بود و شخص مدیر نبود
    if ( strpos( $url, '/wp-json/wp/v2/users' ) !== false && ! current_user_can( 'list_users' ) ) {
        
        // تغییر فرمت خروجی از JSON به صفحه وب
        header( 'Content-Type: text/html; charset=utf-8' );
        
        echo '<div style="text-align: center; margin-top: 100px; direction: rtl;">';
        
        // لینک عکس دلخواه خود را به جای آدرس زیر قرار دهید
        echo '<img src="https://simcablenavid.ir/wp-content/uploads/2026/08/Baner-11.webp" alt="دسترسی مسدود است" style="max-width: 100%; height: auto;" />';
        
        // می‌توانید متن زیر را هم تغییر دهید یا کلاً پاک کنید
        echo '<h2 style="font-family: Tahoma, sans-serif; margin-top: 20px; color: #333;">دسترسی به این بخش مسدود است</h2>';
        echo '</div>';
        
        exit;
    }
});
// کلمه ورود جدید
$custom_login_slug = 'panel-navid';

// ۱. جایگزینی آدرس جدید در تمام لینک‌ها و ایمیل‌های وردپرس
add_filter( 'site_url', function( $url, $path, $scheme ) use ( $custom_login_slug ) {
    if ( strpos( $path, 'wp-login.php' ) !== false ) {
        return str_replace( 'wp-login.php', $custom_login_slug, $url );
    }
    return $url;
}, 10, 3 );

// ۲. مسدود کردن آدرس wp-admin برای افراد غریبه و هدایت آن‌ها به صفحه اصلی
add_action( 'init', function() {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    if ( strpos( $uri, 'wp-admin' ) !== false && ! is_user_logged_in() && ! wp_doing_ajax() && strpos( $uri, 'admin-post.php' ) === false ) {
        wp_safe_redirect( home_url() );
        exit;
    }
});

// ۳. مسدود کردن آدرس قدیمی wp-login.php برای جلوگیری از دسترسی ربات‌ها
add_action( 'login_init', function() use ( $custom_login_slug ) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    
    // اجازه دادن به عملیات‌های ضروری مثل خروج یا بازیابی رمز عبور
    if ( isset( $_GET['action'] ) && in_array( $_GET['action'], array( 'logout', 'rp', 'resetpass', 'lostpassword' ), true ) ) {
        return;
    }
    
    // اگر کسی مستقیماً wp-login.php را باز کرد
    if ( strpos( $uri, 'wp-login.php' ) !== false ) {
        // بررسی اینکه آیا از طریق آدرس سفارشی هدایت شده یا خیر
        $referer = wp_get_referer();
        if ( ! $referer || strpos( $referer, $custom_login_slug ) === false ) {
            wp_safe_redirect( home_url() );
            exit;
        }
    }
});