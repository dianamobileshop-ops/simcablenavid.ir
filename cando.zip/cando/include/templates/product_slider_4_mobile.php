<?php
/**
 * Cando Product Slider 4 Mobile Template
 */
 ?>
<section class="products-slider-container">	
	<div class="zardkooh-products-row">
		<div class="products-row">
			<?php
			while ($skate_carousel_query->have_posts()):
			$skate_carousel_query->the_post();
			global $product, $post, $zardkooh_options;
			$product = wc_get_product( $post->ID );
			?>
			<div class="products-swiper-p-box">
				<a href="<?php the_permalink(); ?>" class="products-swiper-link">
					<div class="products-swiper-img">
						<img alt="<?php the_title(); ?>" class="swiper-lazy" data-src="<?php echo zardkooh_get_product_img($product); ?>" src="<?php echo zardkooh_get_product_img($product); ?>" width="205" height="205">
					</div>
					<div class="products-swiper-title"><?php echo get_the_title(); ?></div>
					<div class="products-swiper-footer">
						<span class="products-swiper-button"><?php _e('View','zardkooh');?></span>
						<div class="products-swiper-price">
							<?php echo $product->get_price_html(); ?>
							<span class="products-swiper-discount"><?php echo zardkooh_get_product_discount_percent($product); ?></span>
						</div>
					</div>
				</a>
			</div>
			<?php endwhile; ?>
		</div>
	</div>
</section>