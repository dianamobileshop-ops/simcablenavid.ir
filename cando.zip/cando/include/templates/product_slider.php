<?php
/**
 * Cando Product Slider Template
 */
 ?>
<section class="products-slider-container <?php if ( $style == 2 ) { echo 'style2'; } else { echo 'style1'; } ?>">
	<div class="products-slider-header">
		<div class="products-slider-header-title">
			<?php if ( $image ) { ?>
				<img src="<?php echo $image; ?>" alt="<?php echo $title; ?>">
			<?php } ?>
			<?php if ( $style == 2 && $subtitle ) { ?>
				<div class="header-title">
					<span><?php echo $title; ?></span>
					<h2><?php echo $subtitle; ?></h2>
				</div>
			<?php } else { ?>							
				<h2><?php echo $title; ?></h2>
			<?php } ?>
		</div>
		<?php if ( $category && $category_link) { ?>
			<a href="<?php echo $cat_link; ?>" class="products-slider-header-more"><?php _e('Show More','zardkooh');?></a>
		<?php } ?>
	</div>
	
	<div class="products-swiper-box">
		<div class="style2-bg"></div>
		<div class="swiper-container swiper-container-products<?php echo $item_count; ?>" <?php language_attributes(); ?>>
			<div class="swiper-wrapper">
				<?php
				while ($nikan_carousel_query->have_posts()):
				$nikan_carousel_query->the_post();
				global $product, $post, $zardkooh_options;
				$product = wc_get_product( $post->ID );
				?>
				<div class="swiper-slide">
					<div class="products-swiper-p-box">
						<a href="<?php the_permalink(); ?>" class="products-swiper-link">
							<div class="products-swiper-img">
								<img alt="<?php the_title(); ?>" class="swiper-lazy" data-src="<?php echo zardkooh_get_product_img($product); ?>" src="<?php echo zardkooh_get_product_img($product); ?>" width="205" height="205">
							</div>
							<div class="products-swiper-title"><?php echo get_the_title(); ?></div>
							<div class="products-swiper-footer">
								<?php if ( !$product->is_in_stock() ) { ?>
									<span class="products-swiper-button out-of-stock"><?php _e('Out Of Stock','zardkooh');?></span>
								<?php } else { ?>
									<span class="products-swiper-button"><?php _e('View','zardkooh');?></span>
									<div class="products-swiper-price">
										<?php echo $product->get_price_html(); ?>
									</div>
								<?php } ?>
							</div>
						</a>
					</div>
				</div>
				
				<?php endwhile; ?>
			</div>
		</div>
		<div class="swiper-button-prev prev-products<?php echo $item_count; ?>"></div>
		<div class="swiper-button-next next-products<?php echo $item_count; ?>"></div>
	</div>
</section>