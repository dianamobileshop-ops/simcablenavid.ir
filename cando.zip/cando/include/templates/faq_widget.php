<?php
/**
 * Cando FAQs Widget Template
 */
 
?>
<div class="zardkooh-faqs">
	<?php if ($title) { ?>
		<h3 class="zardkooh-faqs-title"><?php echo $title; ?></h3>
	<?php } ?>
	<div id="zardkooh-tabs" class="zardkooh-faqs-content">
		<ul class="zardkooh-faqs-side">
			<?php
			$count = 1;
			foreach ( $faqs as $faq ) {
				if ( isset($faq["faq_title"]) && isset($faq["faq_content"]) ) {
					echo '<li><a href="#faqs-'.$count.'">'.$faq["faq_title"].'</a></li>';
					$count++;
				}
			}
			?>
		</ul>
		<div class="zardkooh-faqs-main">
			<?php
			$countt = 1;
			foreach ( $faqs as $faq ) {
				if ( isset($faq["faq_title"]) && isset($faq["faq_content"]) ) {
					echo '<div id="faqs-'.$countt.'">';
						echo '<h4>'.$faq["faq_title"].'</h4>';
						echo $faq["faq_content"]; 
					echo '</div>';
					$countt++;
				}
			}
			?>
		</div>
	</div>
</div>