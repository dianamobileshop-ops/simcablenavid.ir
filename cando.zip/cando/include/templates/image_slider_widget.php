<?php
/**
 * Cando Image Slider Widget Template
 */
 
?>
<div class="zardkooh-blog-slider">
	<div class="zardkooh-blog-swiper-container">
		<ul class="swiper-wrapper">
		<?php
		foreach ( $sliders as $slider ) {
			$image	= $slider['image'];
			$image	= wp_get_attachment_image_src( $slider['image'], 'full' );
			$link   = $slider['link'];
			?>
			<a class="swiper-slide" href="<?php echo esc_url( $link );?>">
				<img src="<?php echo $image[0];?>">
			</a>
		<?php } ?>
		</ul>
	</div>
</div>