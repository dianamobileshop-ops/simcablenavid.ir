<?php
/**
 * Cando Product Slider 3 Template
 */
 
if ( $style ) {
	$item_count = 3;
}
?>
<section class="products-slider-container carpet-swiper <?php if ( $style ) { echo 'style2'; } else { echo 'style1'; } ?>">
	<div class="products-slider-header">
		<div class="products-slider-header-title">
			<?php if ( $style && $subtitle ) { ?>
				<h2><?php echo $title; ?></h2>
				<p><?php echo $subtitle; ?></p>
			<?php } else { ?>							
				<h2><?php echo $title; ?></h2>
			<?php } ?>
		</div>
		<?php if ( $category && $category_link) { ?>
			<a href="<?php echo $cat_link; ?>" class="products-slider-header-more"><?php _e('Show More','zardkooh');?></a>
		<?php } ?>
	</div>
	
	<div class="products-swiper-box">
		<div class="swiper-container swiper-container-carpet-products<?php echo $item_count; ?>" <?php language_attributes(); ?>>
			<div class="swiper-wrapper">
				<?php
				while ($nikan_carousel_query->have_posts()):
				$nikan_carousel_query->the_post();
				global $product, $post, $zardkooh_options;
				$product	= wc_get_product( $post->ID );
				$features	= get_post_meta( $product->get_id(), 'main_features', true);
				$carpet_size= false;
				if ( is_array($features) && isset($features[1]['value']) ) {
					$carpet_size = $features[1]['value'];
				}
				?>
				<div class="swiper-slide">
					<div class="products-swiper-p-box">
						<a href="<?php the_permalink(); ?>" class="products-swiper-link">
							<div class="products-swiper-img">
								<img alt="<?php the_title(); ?>" class="swiper-lazy" data-src="<?php echo zardkooh_get_product_img($product); ?>" src="<?php echo zardkooh_get_product_img($product); ?>" width="205" height="205">
							</div>
							<div class="products-swiper-title">
								<?php echo get_the_title(); ?>
								<?php if ( $carpet_size ) { ?>
									<span><?php echo $carpet_size; ?></span>
								<?php } ?>
							</div>
							<div class="products-swiper-footer">
								<div class="products-swiper-price">
									<?php echo $product->get_price_html(); ?>
								</div>
							</div>
						</a>
						<a href="<?php the_permalink(); ?>"><span class="products-swiper-button"><?php _e('View Product','zardkooh');?></span></a>
					</div>
				</div>
				
				<?php endwhile; ?>
			</div>
			<div class="swiper-button-prev"></div>
			<div class="swiper-button-next"></div>
		</div>
	</div>
</section>