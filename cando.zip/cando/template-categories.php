<?php
/**
 * Template Name: Categories
 */

get_header(); ?>

<div class="container">
	<div class="row">
		<?php zardkooh_template_categories_content(); ?>
	</div>

</div>
	
<div class="container">
	<?php 
		while ( have_posts() ) : the_post(); 
			the_content(); 
		endwhile; // End of the loop.
	?>
</div>

<?php get_footer();