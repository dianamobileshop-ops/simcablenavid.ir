<?php
/**
 * Template Name: Page Builder
 */
get_header(); ?>

<div class="container-fluid main-warp">
		<main id="main" class="site-main" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<?php the_content(); ?>
				</article><!-- #post-## -->

			<?php endwhile; // End of the loop.	?>

		</main><!-- #main -->
</div><!-- .container main -->

<?php get_footer();
