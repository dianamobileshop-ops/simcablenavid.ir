<?php
/**
 * Online proforma (پیش‌فاکتور) builder + customer archive.
 *
 * Navid used to write proformas by hand; this module moves the whole flow
 * into the WP admin: pick a customer (or type a new one), search the live
 * WooCommerce catalog, adjust quantities (units for normal products, meters
 * for meter-sold ones), apply a discount and print a branded RTL sheet —
 * while every proforma and its customer are archived in dedicated tables
 * (dbDelta-managed) for later reference.
 *
 * Security model:
 *  - the admin builder/AJAX endpoints require the table-edit capability and
 *    a nonce;
 *  - the print/share endpoint is public but only reachable through a
 *    32-hex random token stored per proforma (unguessable, no nonce needed:
 *    the URL is meant to be kept/sent around, and full-page caches may hold
 *    it for hours), and it is rate-limited like the other public endpoints.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NPT_Proforma {

	const SLUG        = 'npt-proforma';
	const NONCE       = 'npt_proforma';
	const SEQ_OPTION  = 'npt_proforma_seq';
	const DB_VER_OPT  = 'npt_proforma_db_ver';
	const DB_VERSION  = 2;
	const FIRST_NUM   = 1001;

	public static function init() {
		// Proforma creation lives only in the business panel (/panel/, tab «پیش‌فاکتورها»).
		// The wp-admin submenu is no longer registered; menu() is kept for reference.
		add_action( 'admin_init', array( __CLASS__, 'maybe_install' ) );
		add_action( 'wp_ajax_npt_proforma_search', array( __CLASS__, 'ajax_search' ) );
		add_action( 'wp_ajax_npt_proforma_save', array( __CLASS__, 'ajax_save' ) );
		add_action( 'wp_ajax_npt_proforma_print', array( __CLASS__, 'render_print' ) );
		add_action( 'wp_ajax_nopriv_npt_proforma_print', array( __CLASS__, 'render_print' ) );
		add_action( 'admin_post_npt_proforma_delete', array( __CLASS__, 'handle_delete' ) );

		// Public (front-end shortcode) endpoints: no capability check, but a
		// guest nonce + tight per-IP rate limits + honeypot + server-side
		// pricing instead. Registered for both logged-in and guest visitors
		// so a logged-in non-editor can also use the public form.
		add_action( 'wp_ajax_npt_proforma_search_pub', array( __CLASS__, 'ajax_search_public' ) );
		add_action( 'wp_ajax_nopriv_npt_proforma_search_pub', array( __CLASS__, 'ajax_search_public' ) );
		add_action( 'wp_ajax_npt_proforma_save_pub', array( __CLASS__, 'ajax_save_public' ) );
		add_action( 'wp_ajax_nopriv_npt_proforma_save_pub', array( __CLASS__, 'ajax_save_public' ) );

		add_shortcode( 'navid_proforma', array( __CLASS__, 'shortcode' ) );
	}

	public static function table_customers() {
		global $wpdb;
		return $wpdb->prefix . 'npt_proforma_customers';
	}

	public static function table_proformas() {
		global $wpdb;
		return $wpdb->prefix . 'npt_proformas';
	}

	/**
	 * Create/upgrade the tables once per schema version. Doing this on
	 * admin_init behind a version guard avoids activation-hook ordering
	 * issues and still re-runs whenever the schema changes.
	 */
	public static function maybe_install() {
		if ( (int) get_option( self::DB_VER_OPT, 0 ) >= self::DB_VERSION ) {
			return;
		}
		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}
		global $wpdb;
		$charset = $wpdb->get_charset_collate();

		$customers = 'CREATE TABLE ' . self::table_customers() . " (\n"
			. "id bigint(20) unsigned NOT NULL AUTO_INCREMENT,\n"
			. "name varchar(190) NOT NULL DEFAULT '',\n"
			. "phone varchar(20) NOT NULL DEFAULT '',\n"
			. "company varchar(190) NOT NULL DEFAULT '',\n"
			. "email varchar(190) NOT NULL DEFAULT '',\n"
			. "address text,\n"
			. "created_at datetime NOT NULL,\n"
			. "PRIMARY KEY  (id),\n"
			. "KEY phone (phone)\n"
			. ") $charset;\n";

		$proformas = 'CREATE TABLE ' . self::table_proformas() . " (\n"
			. "id bigint(20) unsigned NOT NULL AUTO_INCREMENT,\n"
			. "number bigint(20) unsigned NOT NULL DEFAULT 0,\n"
			. "token varchar(32) NOT NULL DEFAULT '',\n"
			. "customer_id bigint(20) unsigned NOT NULL DEFAULT 0,\n"
			. "items longtext,\n"
			. "subtotal double NOT NULL DEFAULT 0,\n"
			. "discount double NOT NULL DEFAULT 0,\n"
			. "total double NOT NULL DEFAULT 0,\n"
			. "validity_days smallint(5) unsigned NOT NULL DEFAULT 7,\n"
			. "note text,\n"
			. "source varchar(10) NOT NULL DEFAULT 'admin',\n"
			. "created_by bigint(20) unsigned NOT NULL DEFAULT 0,\n"
			. "created_at datetime NOT NULL,\n"
			. "PRIMARY KEY  (id),\n"
			. "KEY token (token),\n"
			. "KEY customer_id (customer_id)\n"
			. ") $charset;\n";

		dbDelta( $customers );
		dbDelta( $proformas );
		update_option( self::DB_VER_OPT, self::DB_VERSION, false );
	}

	public static function menu() {
		add_submenu_page(
			'navid-price-table-settings',
			'پیش‌فاکتور آنلاین',
			'پیش‌فاکتور',
			npt_edit_capability(),
			self::SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Normalize an Iranian mobile number: Persian/Arabic digits → Latin,
	 * strip separators, 0098/98 prefixes → 0. Returns '' when the result is
	 * not a plausible 11-digit 09… number.
	 */
	public static function normalize_phone( $raw ) {
		$digits = strtr( trim( (string) $raw ), array(
			'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
			'۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
			'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
			'٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
		) );
		$digits = preg_replace( '/[^0-9]/', '', $digits );
		if ( 0 === strpos( $digits, '0098' ) ) {
			$digits = '0' . substr( $digits, 4 );
		} elseif ( 0 === strpos( $digits, '98' ) && 12 === strlen( $digits ) ) {
			$digits = '0' . substr( $digits, 2 );
		}
		if ( ! preg_match( '/^09\d{9}$/', $digits ) ) {
			return '';
		}
		return $digits;
	}

	/* ---------------------------------------------------------------------
	 * AJAX: product search for the builder (admin + public shortcode)
	 * ------------------------------------------------------------------- */
	public static function ajax_search() {
		check_ajax_referer( self::NONCE, 'nonce' );

		if ( ! npt_current_user_can_edit() || ! function_exists( 'wc_get_product' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی لازم را ندارید.' ), 403 );
		}

		wp_send_json_success( array( 'results' => self::search_products( self::query_arg() ) ) );
	}

	/**
	 * Public search: same catalog data the price table already exposes, so
	 * no capability gate — but nonce + a per-IP budget keep it from being
	 * used as a scraping hammer.
	 */
	public static function ajax_search_public() {
		if ( ! check_ajax_referer( self::NONCE, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'نشست شما منقضی شده است. صفحه را تازه کنید و دوباره تلاش کنید.' ), 403 );
		}

		if ( ! function_exists( 'wc_get_product' ) || ! npt_pdf_rate_limit_ok( 'pf_search' ) ) {
			wp_send_json_error( array( 'message' => 'تعداد درخواست‌ها بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.' ), 429 );
		}

		wp_send_json_success( array( 'results' => self::search_products( self::query_arg() ) ) );
	}

	private static function query_arg() {
		return isset( $_POST['q'] ) ? sanitize_text_field( wp_unslash( $_POST['q'] ) ) : '';
	}

	private static function search_products( $q ) {
		if ( mb_strlen( $q ) < 2 ) {
			return array();
		}

		// Title/content search. Alphabetical order + a raised cap: with the old
		// 15/newest-first setup, one large category could fill the whole list
		// and products from every other category never showed up.
		$posts = get_posts( array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 50,
			'orderby'        => 'title',
			'order'          => 'ASC',
			's'              => $q,
		) );

		// WP's `s` never looks at postmeta, so SKU matches are fetched
		// separately and merged in — many items are looked up by their SKU.
		global $wpdb;
		$like    = '%' . $wpdb->esc_like( $q ) . '%';
		$sku_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT p.ID FROM {$wpdb->posts} p"
			. " INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_sku'"
			. " WHERE p.post_type = 'product' AND p.post_status = 'publish' AND m.meta_value LIKE %s"
			. ' ORDER BY p.post_title ASC LIMIT 50', // phpcs:ignore
			$like
		) );

		if ( ! empty( $sku_ids ) ) {
			$ids = array_unique( array_merge(
				wp_list_pluck( $posts, 'ID' ),
				array_map( 'absint', (array) $sku_ids )
			) );
			$posts = get_posts( array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => 50,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'post__in'       => $ids,
			) );
		}

		$results = array();
		foreach ( $posts as $post ) {
			$product = wc_get_product( $post->ID );
			if ( ! $product ) {
				continue;
			}
			$price = $product->get_price();
			if ( '' === $price || ! is_numeric( $price ) ) {
				continue;
			}
			// First category name, so the dropdown can show *where* each hit
			// lives — with hits from many categories visible at once.
			$terms = get_the_terms( $post->ID, 'product_cat' );
			$cat   = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
			$results[] = array(
				'id'    => $product->get_id(),
				'name'  => $product->get_name(),
				'price' => (float) $price,
				'meter' => (bool) npt_meter_is_meter_product( $product->get_id() ),
				'cat'   => $cat,
				'sku'   => (string) $product->get_sku(),
			);
		}

		return $results;
	}

	/**
	 * Jalali date (day-first) of "today + N days", for the اعتبار field on
	 * the print sheet.
	 */
	public static function validity_date( $days ) {
		$ts = current_time( 'timestamp' ) + max( 0, (int) $days ) * DAY_IN_SECONDS;
		// Plain date(), NOT date_i18n(): the Persian locale makes date_i18n()
		// return Jalali values, which the converter then shifted by -621 years.
		list( $jy, $jm, $jd ) = npt_gregorian_to_jalali(
			(int) date( 'Y', $ts ),
			(int) date( 'n', $ts ),
			(int) date( 'j', $ts )
		);
		return npt_to_persian_digits( sprintf( '%02d/%02d/%04d', $jd, $jm, $jy ) );
	}

	/* ---------------------------------------------------------------------
	 * AJAX: save proforma + upsert customer (admin)
	 * ------------------------------------------------------------------- */
	public static function ajax_save() {
		check_ajax_referer( self::NONCE, 'nonce' );

		if ( ! npt_current_user_can_edit() ) {
			wp_send_json_error( array( 'message' => 'دسترسی لازم را ندارید.' ), 403 );
		}

		$name    = isset( $_POST['c_name'] ) ? sanitize_text_field( wp_unslash( $_POST['c_name'] ) ) : '';
		$phone   = self::normalize_phone( isset( $_POST['c_phone'] ) ? wp_unslash( $_POST['c_phone'] ) : '' );
		$company = isset( $_POST['c_company'] ) ? sanitize_text_field( wp_unslash( $_POST['c_company'] ) ) : '';
		$email   = isset( $_POST['c_email'] ) ? sanitize_email( wp_unslash( $_POST['c_email'] ) ) : '';
		$address = isset( $_POST['c_address'] ) ? sanitize_textarea_field( wp_unslash( $_POST['c_address'] ) ) : '';
		$note    = isset( $_POST['p_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['p_note'] ) ) : '';

		if ( '' === trim( $name ) ) {
			wp_send_json_error( array( 'message' => 'نام مشتری الزامی است.' ) );
		}
		if ( '' === $phone ) {
			wp_send_json_error( array( 'message' => 'شماره موبایل معتبر وارد کنید (مثال: 09121234567).' ) );
		}

		$raw_items = isset( $_POST['items'] ) ? wp_unslash( $_POST['items'] ) : '';
		$items     = json_decode( (string) $raw_items, true );
		if ( ! is_array( $items ) || empty( $items ) ) {
			wp_send_json_error( array( 'message' => 'حداقل یک قلم کالا اضافه کنید.' ) );
		}

		// The seller edits names/prices by design, so the admin path trusts
		// the submitted rows — but totals are always recomputed server-side.
		$clean = array();
		foreach ( $items as $item ) {
			$label = isset( $item['name'] ) ? sanitize_text_field( (string) $item['name'] ) : '';
			$qty   = isset( $item['qty'] ) ? (float) $item['qty'] : 0.0;
			$price = isset( $item['price'] ) ? (float) $item['price'] : 0.0;
			$meter = ! empty( $item['meter'] );
			if ( '' === $label || $qty <= 0 || $price < 0 ) {
				continue;
			}
			$clean[] = array(
				'name'  => $label,
				'qty'   => $qty,
				'price' => $price,
				'meter' => $meter,
			);
		}
		if ( empty( $clean ) ) {
			wp_send_json_error( array( 'message' => 'هیچ قلم معتبری در فهرست نیست (مقدار باید بزرگ‌تر از صفر باشد).' ) );
		}

		$discount = isset( $_POST['discount'] ) ? (float) wp_unslash( $_POST['discount'] ) : 0.0;
		$validity = isset( $_POST['validity_days'] ) ? max( 0, (int) wp_unslash( $_POST['validity_days'] ) ) : 7;
		$validity = min( $validity, 365 );

		$saved = self::persist_proforma(
			array( 'name' => $name, 'phone' => $phone, 'company' => $company, 'email' => $email, 'address' => $address ),
			$clean, $discount, $validity, $note, 'admin'
		);
		if ( ! $saved ) {
			wp_send_json_error( array( 'message' => 'ذخیره‌سازی ناموفق بود. دوباره تلاش کنید.' ) );
		}
		wp_send_json_success( self::save_response( $saved ) );
	}

	/* ---------------------------------------------------------------------
	 * AJAX: save proforma from the public shortcode
	 *
	 * Trusts NOTHING from the visitor except quantities and their own
	 * contact details: every line is re-priced from the live WooCommerce
	 * product, discount is forced to zero and validity to the default —
	 * a visitor must not be able to hand themselves a price or a discount.
	 * ------------------------------------------------------------------- */
	public static function ajax_save_public() {
		// A full-page cache can serve a guest nonce that has since expired, so
		// the failure gets a message that tells the visitor to reload instead
		// of the bare "-1" wp_die() response.
		if ( ! check_ajax_referer( self::NONCE, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'نشست شما منقضی شده است. صفحه را تازه کنید و دوباره فرم را پر کنید.' ), 403 );
		}

		if ( ! npt_pdf_rate_limit_ok( 'pf_save' ) ) {
			wp_send_json_error( array( 'message' => 'تعداد درخواست‌ها بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.' ), 429 );
		}
		// Honeypot: invisible to real visitors, irresistible to bots.
		if ( '' !== trim( (string) ( isset( $_POST['npt_website'] ) ? wp_unslash( $_POST['npt_website'] ) : '' ) ) ) {
			wp_send_json_error( array( 'message' => 'خطا در اعتبارسنجی فرم.' ), 400 );
		}
		if ( ! function_exists( 'wc_get_product' ) ) {
			wp_send_json_error( array( 'message' => 'فروشگاه فعال نیست.' ), 503 );
		}
		// Public visitors never trigger admin_init, so make sure the tables
		// (and the source column) exist before writing.
		self::maybe_install();

		$name    = isset( $_POST['c_name'] ) ? sanitize_text_field( wp_unslash( $_POST['c_name'] ) ) : '';
		$phone   = self::normalize_phone( isset( $_POST['c_phone'] ) ? wp_unslash( $_POST['c_phone'] ) : '' );
		$company = isset( $_POST['c_company'] ) ? sanitize_text_field( wp_unslash( $_POST['c_company'] ) ) : '';
		$email   = isset( $_POST['c_email'] ) ? sanitize_email( wp_unslash( $_POST['c_email'] ) ) : '';
		$address = isset( $_POST['c_address'] ) ? sanitize_textarea_field( wp_unslash( $_POST['c_address'] ) ) : '';
		$note    = isset( $_POST['p_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['p_note'] ) ) : '';

		if ( '' === trim( $name ) ) {
			wp_send_json_error( array( 'message' => 'نام و نام خانوادگی الزامی است.' ) );
		}
		if ( '' === $phone ) {
			wp_send_json_error( array( 'message' => 'شماره موبایل معتبر وارد کنید (مثال: 09121234567).' ) );
		}

		$raw_items = isset( $_POST['items'] ) ? wp_unslash( $_POST['items'] ) : '';
		$items     = json_decode( (string) $raw_items, true );
		if ( ! is_array( $items ) || empty( $items ) ) {
			wp_send_json_error( array( 'message' => 'حداقل یک قلم کالا اضافه کنید.' ) );
		}
		if ( count( $items ) > 60 ) {
			wp_send_json_error( array( 'message' => 'تعداد اقلام بیش از حد مجاز است.' ) );
		}

		$clean = array();
		foreach ( $items as $item ) {
			$pid = isset( $item['id'] ) ? absint( $item['id'] ) : 0;
			$qty = isset( $item['qty'] ) ? (float) $item['qty'] : 0.0;
			if ( ! $pid || $qty <= 0 || $qty > 1000000 ) {
				continue;
			}
			$product = wc_get_product( $pid );
			if ( ! $product || 'publish' !== $product->get_status() ) {
				continue;
			}
			$price = $product->get_price();
			if ( '' === $price || ! is_numeric( $price ) ) {
				continue;
			}
			$clean[] = array(
				'name'  => $product->get_name(),
				'qty'   => $qty,
				'price' => (float) $price,
				'meter' => (bool) npt_meter_is_meter_product( $pid ),
			);
		}
		if ( empty( $clean ) ) {
			wp_send_json_error( array( 'message' => 'هیچ قلم معتبری در فهرست نیست.' ) );
		}

		$saved = self::persist_proforma(
			array( 'name' => $name, 'phone' => $phone, 'company' => $company, 'email' => $email, 'address' => $address ),
			$clean, 0.0, 7, $note, 'site'
		);
		if ( ! $saved ) {
			wp_send_json_error( array( 'message' => 'ذخیره‌سازی ناموفق بود. دوباره تلاش کنید.' ) );
		}

		// Answer the visitor first, then tell the owner (SMS / push take a
		// second or two and must not make the customer wait).
		npt_finish_json_then( array( 'success' => true, 'data' => self::save_response( $saved ) ), function () use ( $saved, $name, $phone ) {
			do_action( 'npt_proforma_created', $saved, array(
				'name'   => $name,
				'phone'  => $phone,
				'total'  => $saved['total'],
				'source' => 'site',
			) );
		} );
	}

	/**
	 * Shared write path: upsert the customer by phone, take the next
	 * proforma number, store the row. Both endpoints funnel through here
	 * so the archive stays consistent no matter who creates the proforma.
	 */
	private static function persist_proforma( $customer, $clean_items, $discount, $validity, $note, $source ) {
		global $wpdb;
		$now = current_time( 'mysql' );

		$subtotal = 0.0;
		foreach ( $clean_items as $item ) {
			$subtotal += (float) $item['qty'] * (float) $item['price'];
		}
		$discount = max( 0.0, min( (float) $discount, $subtotal ) );

		// Upsert the customer by phone (the archive's dedupe key).
		$existing = $wpdb->get_var( $wpdb->prepare(
			'SELECT id FROM ' . self::table_customers() . ' WHERE phone = %s LIMIT 1', // phpcs:ignore
			$customer['phone']
		) );
		if ( $existing && 'admin' !== $source ) {
			// A public visitor only proves they typed a number, not that they own
			// it, so they must never overwrite the stored details of an existing
			// customer. Only blanks are filled in.
			$customer_id = (int) $existing;
			$row         = $wpdb->get_row( $wpdb->prepare(
				'SELECT company, email, address FROM ' . self::table_customers() . ' WHERE id = %d', // phpcs:ignore
				$customer_id
			), ARRAY_A );
			$fill = array();
			foreach ( array( 'company', 'email', 'address' ) as $field ) {
				if ( $row && '' === trim( (string) $row[ $field ] ) && '' !== $customer[ $field ] ) {
					$fill[ $field ] = $customer[ $field ];
				}
			}
			if ( $fill ) {
				$wpdb->update( self::table_customers(), $fill, array( 'id' => $customer_id ) );
			}
		} elseif ( $existing ) {
			$customer_id = (int) $existing;
			$wpdb->update(
				self::table_customers(),
				array(
					'name'    => $customer['name'],
					'company' => $customer['company'],
					'email'   => $customer['email'],
					'address' => $customer['address'],
				),
				array( 'id' => $customer_id ),
				array( '%s', '%s', '%s', '%s' ),
				array( '%d' )
			);
		} else {
			$wpdb->insert(
				self::table_customers(),
				array(
					'name'       => $customer['name'],
					'phone'      => $customer['phone'],
					'company'    => $customer['company'],
					'email'      => $customer['email'],
					'address'    => $customer['address'],
					'created_at' => $now,
				),
				array( '%s', '%s', '%s', '%s', '%s', '%s' )
			);
			$customer_id = (int) $wpdb->insert_id;
		}

		// Take the next number and insert the row under one DB lock, so two
		// simultaneous saves can never share a proforma number.
		$locked = (int) $wpdb->get_var( "SELECT GET_LOCK('npt_pf_seq', 5)" );
		$max    = (int) $wpdb->get_var( 'SELECT MAX(number) FROM ' . self::table_proformas() ); // phpcs:ignore
		$number = max( (int) get_option( self::SEQ_OPTION, self::FIRST_NUM ), $max + 1 );
		update_option( self::SEQ_OPTION, $number + 1, false );

		$token = bin2hex( random_bytes( 16 ) );
		$wpdb->insert(
			self::table_proformas(),
			array(
				'number'        => $number,
				'token'         => $token,
				'customer_id'   => $customer_id,
				'items'         => wp_json_encode( $clean_items, JSON_UNESCAPED_UNICODE ),
				'subtotal'      => $subtotal,
				'discount'      => $discount,
				'total'         => $subtotal - $discount,
				'validity_days' => (int) $validity,
				'note'          => $note,
				'source'        => $source,
				'created_by'    => get_current_user_id(),
				'created_at'    => $now,
			),
			array( '%d', '%s', '%d', '%s', '%f', '%f', '%f', '%d', '%s', '%s', '%d', '%s' )
		);

		$id = (int) $wpdb->insert_id;
		if ( $locked ) {
			$wpdb->query( "DO RELEASE_LOCK('npt_pf_seq')" );
		}
		if ( ! $id ) {
			return null;
		}
		return array( 'id' => $id, 'number' => $number, 'token' => $token, 'total' => $subtotal - $discount );
	}

	private static function save_response( $saved ) {
		return array(
			'number'    => npt_to_persian_digits( (string) $saved['number'] ),
			'print_url' => add_query_arg( array(
				'action' => 'npt_proforma_print',
				'token'  => $saved['token'],
			), admin_url( 'admin-ajax.php' ) ),
		);
	}

	/* ---------------------------------------------------------------------
	 * Admin page: builder / archive / customers
	 * ------------------------------------------------------------------- */
	public static function render_page() {
		if ( ! npt_current_user_can_edit() ) {
			wp_die( esc_html__( 'دسترسی لازم برای این بخش را ندارید.', 'navid-price-table' ) );
		}

		$tab      = isset( $_GET['pf_tab'] ) ? sanitize_key( $_GET['pf_tab'] ) : 'new'; // phpcs:ignore
		$tabs     = array(
			'new'       => 'پیش‌فاکتور جدید',
			'list'      => 'آرشیو پیش‌فاکتورها',
			'customers' => 'آرشیو مشتریان',
		);
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'new';
		}
		$base = admin_url( 'admin.php?page=' . self::SLUG );
		?>
		<div class="wrap">
			<h1>پیش‌فاکتور آنلاین</h1>
			<nav class="nav-tab-wrapper">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<a href="<?php echo esc_url( add_query_arg( 'pf_tab', $key, $base ) ); ?>" class="nav-tab <?php echo $tab === $key ? 'nav-tab-active' : ''; ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</nav>
			<?php
			if ( 'list' === $tab ) {
				self::render_list( $base );
			} elseif ( 'customers' === $tab ) {
				self::render_customers( $base );
			} else {
				self::render_builder( $base );
			}
			?>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Public shortcode: [navid_proforma]
	 *
	 * Same builder as the admin tab, but visitors only choose products and
	 * quantities — prices come from the catalog, and discount/validity are
	 * not offered at all (the server forces them anyway).
	 * ------------------------------------------------------------------- */
	public static function shortcode( $atts = array() ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return '<p>' . esc_html__( 'برای استفاده از فرم پیش‌فاکتور، افزونه ووکامرس باید فعال باشد.', 'navid-price-table' ) . '</p>';
		}
		self::maybe_install();
		ob_start();
		self::render_builder( '', true );
		return (string) ob_get_clean();
	}

	/** Builder for the business panel's «پیش‌فاکتور جدید» view. */
	public static function render_panel_builder() {
		self::maybe_install();
		self::render_builder( '' );
	}

	private static function render_builder( $base, $public = false ) {
		// Prefill from the customers archive: ?pf_tab=new&customer=ID
		$prefill = array( 'name' => '', 'phone' => '', 'company' => '', 'email' => '', 'address' => '' );
		if ( ! $public && isset( $_GET['customer'] ) ) { // phpcs:ignore
			global $wpdb;
			$cid = (int) $_GET['customer']; // phpcs:ignore
			$row = $cid ? $wpdb->get_row( $wpdb->prepare( 'SELECT name, phone, company, email, address FROM ' . self::table_customers() . ' WHERE id = %d', $cid ) ) : null; // phpcs:ignore
			if ( $row ) {
				$prefill = array(
					'name'    => $row->name,
					'phone'   => $row->phone,
					'company' => $row->company,
					'email'   => $row->email,
					'address' => $row->address,
				);
			}
		}

		$unit_hint = 'IRR' === npt_currency_unit()
			? 'قیمت‌ها را به تومان وارد کنید؛ در چاپ، خودکار به ریال نمایش داده می‌شود.'
			: 'قیمت‌ها به تومان محاسبه و چاپ می‌شوند.';

		$hcss      = vsprintf( '#%02x%02x%02x', npt_header_color_rgb() );
		$acss      = vsprintf( '#%02x%02x%02x', npt_accent_color_rgb() );
		$save_text = $public ? 'ثبت و دریافت پیش‌فاکتور' : 'ذخیره و ساخت پیش‌فاکتور';
		?>
		<style>
			.nptpf { max-width: 1000px; }
			.nptpf-box { background: #fff; border: 1px solid #dcdcde; border-radius: 8px; padding: 16px 18px; margin: 14px 0; }
			.nptpf-box h2 { margin-top: 0; }
			.nptpf-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 12px; }
			.nptpf-grid label { display: block; font-weight: 600; margin-bottom: 4px; }
			.nptpf-grid input, .nptpf-grid textarea { width: 100%; }
			.nptpf-search { position: relative; max-width: 520px; }
			.nptpf-results { position: absolute; top: 100%; right: 0; left: 0; background: #fff; border: 1px solid #c3c4c7; border-radius: 0 0 6px 6px; box-shadow: 0 6px 14px rgba(0,0,0,.12); z-index: 50; max-height: 320px; overflow: auto; display: none; }
			.nptpf-results button { display: block; width: 100%; text-align: right; background: none; border: none; border-bottom: 1px solid #f0f0f1; padding: 8px 12px; cursor: pointer; font-size: 13px; }
			.nptpf-results button:hover { background: #f0f6fc; }
			.nptpf-results .p { color: #2271b1; font-weight: 700; }
			.nptpf-results .m { display: inline-block; margin-inline-start: 6px; padding: 0 7px; border-radius: 999px; background: #28a745; color: #fff; font-size: 10px; font-weight: 700; }
			.nptpf-results .c { display: inline-block; margin-inline-start: 6px; padding: 0 7px; border-radius: 999px; background: #e7eaf3; color: #3c4a6b; font-size: 10px; font-weight: 700; }
			.nptpf-results .s { direction: ltr; display: inline-block; margin-inline-start: 6px; color: #8a8a8a; font-size: 11px; }
			.nptpf-items { width: 100%; border-collapse: collapse; margin-top: 10px; }
			.nptpf-items th, .nptpf-items td { border: 1px solid #dcdcde; padding: 6px 8px; font-size: 13px; vertical-align: middle; }
			.nptpf-items input { width: 100%; min-width: 70px; }
			.nptpf-items .rm { color: #b32d2e; background: none; border: none; cursor: pointer; font-size: 16px; }
			.nptpf-totals { margin-top: 12px; font-size: 14px; }
			.nptpf-totals .row { display: flex; justify-content: space-between; max-width: 420px; margin-inline-start: auto; padding: 3px 0; }
			.nptpf-totals .grand { font-weight: 800; font-size: 16px; border-top: 2px solid #2271b1; margin-top: 6px; padding-top: 8px; }
			.nptpf-empty-row { color: #8a8a8a; text-align: center; }
			#nptpf-save { margin-top: 14px; height: 34px; padding: 0 26px; font-size: 14px; }
			.nptpf-done { margin-top: 14px; padding: 12px 16px; border-inline-start: 4px solid #00a32a; background: #edfaef; display: none; }
			.nptpf-done a { font-weight: 700; }
			<?php if ( $public ) : ?>
			/* Standalone front-end skin: the admin CSS above assumes WP-admin
			   input/button styling, which a theme's page does not provide. */
			@font-face { font-family: 'NPTPfVazir'; src: url('<?php echo esc_url( NPT_URL ); ?>vendor/fonts/Vazirmatn-Regular.ttf') format('truetype'); font-weight: 400; font-style: normal; font-display: swap; }
			@font-face { font-family: 'NPTPfVazir'; src: url('<?php echo esc_url( NPT_URL ); ?>vendor/fonts/Vazirmatn-Bold.ttf') format('truetype'); font-weight: 700; font-style: normal; font-display: swap; }
			.nptpf { direction: rtl; max-width: 880px; margin: 0 auto; font-family: 'NPTPfVazir', Tahoma, Arial, sans-serif; font-size: 14px; line-height: 1.9; color: #222; }
			.nptpf *, .nptpf *::before, .nptpf *::after { box-sizing: border-box; }
			.nptpf-box { border-color: #e6e9ec; box-shadow: 0 2px 10px rgba(10,25,60,.06); }
			.nptpf-box h2 { font-size: 16px; font-weight: 700; color: <?php echo esc_html( $hcss ); ?>; }
			.nptpf label { font-size: 13.5px; }
			.nptpf input, .nptpf textarea { font-family: inherit; font-size: 14px; color: #222; background: #fff; border: 1px solid #c9ced2; border-radius: 6px; padding: 8px 10px; }
			.nptpf input:focus, .nptpf textarea:focus { outline: none; border-color: <?php echo esc_html( $acss ); ?>; box-shadow: 0 0 0 2px rgba(0,0,0,.07); }
			.nptpf .description { color: #666; font-size: 12.5px; margin: 8px 0 0; }
			.nptpf-items-wrap { overflow-x: auto; }
			.nptpf-items { min-width: 560px; }
			.nptpf-items th { background: <?php echo esc_html( $hcss ); ?>; color: #fff; border-color: <?php echo esc_html( $hcss ); ?>; font-weight: 700; }
			.nptpf-btn { display: inline-block; margin-top: 14px; padding: 10px 30px; border: none; border-radius: 8px; background: <?php echo esc_html( $acss ); ?>; color: #fff; font-family: inherit; font-size: 15px; font-weight: 700; cursor: pointer; }
			.nptpf-btn:hover { filter: brightness(.94); }
			.nptpf-btn:disabled { opacity: .6; cursor: default; }
			.nptpf-hp { position: absolute !important; left: -9999px !important; width: 1px; height: 1px; overflow: hidden; opacity: 0; }
			.nptpf-price-cell { text-align: center; font-weight: 700; }
			<?php endif; ?>
		</style>
		<div class="nptpf">
			<div class="nptpf-box">
				<h2><?php echo $public ? 'مشخصات شما' : 'مشخصات مشتری'; ?></h2>
				<?php if ( $public ) : ?>
				<p class="description">فرم زیر را پر کنید و اقلام مورد نظر را اضافه کنید؛ پیش‌فاکتور شما برای کارشناسان ما ارسال می‌شود و در اسرع وقت با شما تماس می‌گیریم.</p>
				<?php endif; ?>
				<div class="nptpf-grid">
					<div>
						<label for="nptpf-name">نام و نام خانوادگی *</label>
						<input type="text" id="nptpf-name" value="<?php echo esc_attr( $prefill['name'] ); ?>">
					</div>
					<div>
						<label for="nptpf-phone">موبایل *</label>
						<input type="text" id="nptpf-phone" dir="ltr" value="<?php echo esc_attr( $prefill['phone'] ); ?>" placeholder="09121234567">
					</div>
					<div>
						<label for="nptpf-company">شرکت / فروشگاه (اختیاری)</label>
						<input type="text" id="nptpf-company" value="<?php echo esc_attr( $prefill['company'] ); ?>">
					</div>
					<div>
						<label for="nptpf-email">ایمیل (اختیاری)</label>
						<input type="email" id="nptpf-email" dir="ltr" value="<?php echo esc_attr( $prefill['email'] ); ?>">
					</div>
					<div style="grid-column: 1 / -1;">
						<label for="nptpf-address">آدرس (اختیاری)</label>
						<textarea id="nptpf-address" rows="2"><?php echo esc_textarea( $prefill['address'] ); ?></textarea>
					</div>
				</div>
				<?php if ( $public ) : ?>
				<div>
					<label for="nptpf-website" class="nptpf-hp" aria-hidden="true">وب‌سایت</label>
					<input type="text" id="nptpf-website" class="nptpf-hp" name="npt_website" tabindex="-1" autocomplete="off" aria-hidden="true" value="">
				</div>
				<?php else : ?>
				<p class="description">اگر شماره موبایل قبلاً در آرشیو باشد، مشخصات همان مشتری به‌روزرسانی می‌شود؛ در غیر این صورت مشتری جدید ثبت می‌گردد. برای قرار دادن همین فرم در سایت، شورت‌کد <code>[navid_proforma]</code> را در یک برگه بگذارید.</p>
				<?php endif; ?>
			</div>

			<div class="nptpf-box">
				<h2>اقلام پیش‌فاکتور</h2>
				<div class="nptpf-search">
					<input type="text" id="nptpf-q" placeholder="جست‌وجوی محصول (حداقل ۲ حرف)…" style="width:100%">
					<div class="nptpf-results" id="nptpf-results"></div>
				</div>
				<div class="nptpf-items-wrap">
				<table class="nptpf-items">
					<thead>
						<tr>
							<th style="width:32px">#</th>
							<th>شرح کالا</th>
							<th style="width:110px">مقدار</th>
							<th style="width:70px">واحد</th>
							<th style="width:150px">قیمت واحد (<?php echo $public ? esc_html( npt_currency_word() ) : 'تومان'; ?>)</th>
							<th style="width:150px">مبلغ کل</th>
							<th style="width:36px"></th>
						</tr>
					</thead>
					<tbody id="nptpf-rows">
						<tr class="nptpf-empty-row"><td colspan="7">با جست‌وجوی بالا، محصول را به فهرست اضافه کنید.</td></tr>
					</tbody>
				</table>
				</div>
				<div class="nptpf-totals">
					<div class="row"><span>جمع کل</span><span id="nptpf-subtotal">۰</span></div>
					<?php if ( ! $public ) : ?>
					<div class="row">
						<label for="nptpf-discount" style="cursor:pointer">تخفیف (تومان)</label>
						<input type="number" id="nptpf-discount" min="0" step="any" value="0" style="width:140px">
					</div>
					<?php endif; ?>
					<div class="row grand"><span>مبلغ قابل پرداخت</span><span id="nptpf-grand">۰</span></div>
				</div>
			</div>

			<div class="nptpf-box">
				<h2>شرایط پیش‌فاکتور</h2>
				<div class="nptpf-grid">
					<?php if ( ! $public ) : ?>
					<div>
						<label for="nptpf-validity">اعتبار (روز)</label>
						<input type="number" id="nptpf-validity" min="0" max="365" value="7">
					</div>
					<?php endif; ?>
					<div style="grid-column: 1 / -1;">
						<label for="nptpf-note"><?php echo $public ? 'توضیحات (اختیاری)' : 'توضیحات روی پیش‌فاکتور (اختیاری)'; ?></label>
						<textarea id="nptpf-note" rows="2" placeholder="مثال: قیمت‌ها بدون احتساب هزینه ارسال است."></textarea>
					</div>
				</div>
				<?php if ( ! $public ) : ?>
				<p class="description"><?php echo esc_html( $unit_hint ); ?></p>
				<?php endif; ?>
				<button type="button" class="<?php echo $public ? 'nptpf-btn' : 'button button-primary'; ?>" id="nptpf-save"><?php echo esc_html( $save_text ); ?></button>
				<div class="nptpf-done" id="nptpf-done"></div>
			</div>
		</div>
		<script>
		(function () {
			var nonce = <?php echo wp_json_encode( wp_create_nonce( self::NONCE ) ); ?>;
			var ajax = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
			var meterWord = <?php echo wp_json_encode( __( 'متر', 'navid-price-table' ) ); ?>;
			var unitWord = <?php echo wp_json_encode( __( 'کلاف', 'navid-price-table' ) ); ?>;
			var isPublic = <?php echo $public ? 'true' : 'false'; ?>;
			var actSearch = <?php echo wp_json_encode( $public ? 'npt_proforma_search_pub' : 'npt_proforma_search' ); ?>;
			var actSave = <?php echo wp_json_encode( $public ? 'npt_proforma_save_pub' : 'npt_proforma_save' ); ?>;
			var saveText = <?php echo wp_json_encode( $save_text ); ?>;
			// The seller always types Toman; the public form shows the site's
			// display unit (Rial = ×10) so it matches the published price table.
			// Server-side storage stays Toman in both cases.
			var factor = isPublic ? <?php echo (int) npt_currency_factor(); ?> : 1;
			var currency = isPublic ? <?php echo wp_json_encode( npt_currency_word() ); ?> : <?php echo wp_json_encode( __( 'تومان', 'navid-price-table' ) ); ?>;
			var fa = function (s) { return String(s).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; }); };
			var money = function (n) { return fa(Math.round(n * factor).toLocaleString('en-US')); };
			var rows = [];

			function fmtPrice(n) {
				return fa(Math.round(Number(n) * factor).toLocaleString('en-US'));
			}

			function recalc() {
				var sub = 0;
				rows.forEach(function (r) {
					r._line = (parseFloat(r.qty) || 0) * (parseFloat(r.price) || 0);
					sub += r._line;
				});
				var discEl = document.getElementById('nptpf-discount');
				var disc = discEl ? Math.min(Math.max(parseFloat(discEl.value) || 0, 0), sub) : 0;
				document.getElementById('nptpf-subtotal').textContent = money(sub) + ' ' + currency;
				document.getElementById('nptpf-grand').textContent = money(sub - disc) + ' ' + currency;
			}

			function draw() {
				var tb = document.getElementById('nptpf-rows');
				tb.innerHTML = '';
				if (!rows.length) {
					tb.innerHTML = '<tr class="nptpf-empty-row"><td colspan="7">با جست‌وجوی بالا، محصول را به فهرست اضافه کنید.</td></tr>';
					recalc();
					return;
				}
				rows.forEach(function (r, i) {
					var tr = document.createElement('tr');
					var unit = r.meter ? meterWord : unitWord;
					tr.innerHTML = '<td>' + (i + 1) + '</td>'
						+ '<td>' + r.name.replace(/</g, '&lt;') + '</td>'
						+ '<td><input type="number" min="0" step="any" data-k="qty" value="' + r.qty + '"></td>'
						+ '<td style="text-align:center">' + unit + '</td>'
						// Visitors never edit prices: the catalog is the only source.
						+ (isPublic
							? '<td class="nptpf-price-cell">' + fmtPrice(r.price) + '</td>'
							: '<td><input type="number" min="0" step="any" data-k="price" value="' + r.price + '"></td>')
						+ '<td style="text-align:center" data-line></td>'
						+ '<td><button type="button" class="rm" title="حذف">×</button></td>';
					tr.querySelector('[data-k="qty"]').addEventListener('input', function () { r.qty = this.value; recalc(); paint(); });
					if (!isPublic) {
						tr.querySelector('[data-k="price"]').addEventListener('input', function () { r.price = this.value; recalc(); paint(); });
					}
					tr.querySelector('.rm').addEventListener('click', function () { rows.splice(i, 1); draw(); });
					tb.appendChild(tr);
				});
				recalc();
				paint();
			}

			function paint() {
				var trs = document.querySelectorAll('#nptpf-rows tr');
				rows.forEach(function (r, i) {
					if (trs[i] && trs[i].querySelector('[data-line]')) {
						trs[i].querySelector('[data-line]').textContent = fmtPrice(r._line || 0);
					}
				});
			}

			var timer = null;
			document.getElementById('nptpf-q').addEventListener('input', function () {
				clearTimeout(timer);
				var q = this.value.trim();
				if (q.length < 2) { document.getElementById('nptpf-results').style.display = 'none'; return; }
				timer = setTimeout(function () {
					var fd = new FormData();
					fd.append('action', actSearch);
					fd.append('nonce', nonce);
					fd.append('q', q);
					fetch(ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
						.then(function (r) { return r.json(); })
						.then(function (res) {
							var box = document.getElementById('nptpf-results');
							if (!res || !res.success) {
								box.innerHTML = '<button type="button" disabled>' + ((res && res.data && res.data.message) ? res.data.message : 'خطا در جست‌وجو.') + '</button>';
								box.style.display = 'block';
								return;
							}
							if (!res.data.results.length) { box.innerHTML = '<button type="button" disabled>موردی یافت نشد.</button>'; box.style.display = 'block'; return; }
							box.innerHTML = '';
							res.data.results.forEach(function (p) {
								var b = document.createElement('button');
								b.type = 'button';
								b.innerHTML = p.name.replace(/</g, '&lt;')
									+ (p.meter ? ' <span class="m">متر</span>' : '')
									+ (p.cat ? ' <span class="c">' + p.cat.replace(/</g, '&lt;') + '</span>' : '')
									+ (p.sku && !isPublic ? ' <span class="s">' + p.sku.replace(/</g, '&lt;') + '</span>' : '')
									+ ' <span class="p">' + fmtPrice(p.price) + '</span>';
								b.addEventListener('click', function () {
									rows.push({ id: p.id, name: p.name, qty: 1, price: p.price, meter: p.meter });
									draw();
									box.style.display = 'none';
									document.getElementById('nptpf-q').value = '';
								});
								box.appendChild(b);
							});
							box.style.display = 'block';
						})
						.catch(function () {
							var box = document.getElementById('nptpf-results');
							box.style.display = 'none';
						});
				}, 300);
			});
			document.addEventListener('click', function (e) {
				if (!e.target.closest('.nptpf-search')) {
					document.getElementById('nptpf-results').style.display = 'none';
				}
			});

			var discountEl = document.getElementById('nptpf-discount');
			if (discountEl) { discountEl.addEventListener('input', recalc); }

			document.getElementById('nptpf-save').addEventListener('click', function () {
				var btn = this, done = document.getElementById('nptpf-done');
				if (!rows.length) {
					done.style.display = 'block';
					done.style.borderColor = '#b32d2e';
					done.textContent = 'حداقل یک قلم کالا اضافه کنید.';
					return;
				}
				btn.disabled = true;
				btn.textContent = <?php echo wp_json_encode( __( 'در حال ذخیره...', 'navid-price-table' ) ); ?>;
				var fd = new FormData();
				fd.append('action', actSave);
				fd.append('nonce', nonce);
				fd.append('c_name', document.getElementById('nptpf-name').value);
				fd.append('c_phone', document.getElementById('nptpf-phone').value);
				fd.append('c_company', document.getElementById('nptpf-company').value);
				fd.append('c_email', document.getElementById('nptpf-email').value);
				fd.append('c_address', document.getElementById('nptpf-address').value);
				fd.append('p_note', document.getElementById('nptpf-note').value);
				if (isPublic) {
					fd.append('npt_website', document.getElementById('nptpf-website').value);
					// Only id + qty leave the browser; the server re-prices every line.
					fd.append('items', JSON.stringify(rows.map(function (r) { return { id: r.id, qty: r.qty }; })));
				} else {
					fd.append('discount', document.getElementById('nptpf-discount').value);
					fd.append('validity_days', document.getElementById('nptpf-validity').value);
					fd.append('items', JSON.stringify(rows));
				}
				fetch(ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (res) {
						btn.disabled = false;
						btn.textContent = saveText;
						done.style.display = 'block';
						if (res && res.success) {
							done.style.borderColor = '#00a32a';
							done.innerHTML = (isPublic
								? 'پیش‌فاکتور شما به شماره <strong>' + res.data.number + '</strong> ثبت شد و برای کارشناسان ما ارسال گردید. '
								: 'پیش‌فاکتور شماره <strong>' + res.data.number + '</strong> ذخیره شد. ')
								+ '<a target="_blank" rel="noopener" href="' + res.data.print_url + '">مشاهده و چاپ</a>';
							rows = [];
							draw();
							if (isPublic) {
								['nptpf-name', 'nptpf-phone', 'nptpf-company', 'nptpf-email', 'nptpf-address', 'nptpf-note']
									.forEach(function (id) { document.getElementById(id).value = ''; });
							}
						} else {
							done.style.borderColor = '#b32d2e';
							done.textContent = (res && res.data && res.data.message) ? res.data.message : 'خطا در ذخیره‌سازی.';
						}
					})
					.catch(function () {
						btn.disabled = false;
						btn.textContent = saveText;
						done.style.display = 'block';
						done.style.borderColor = '#b32d2e';
						done.textContent = 'خطا در ارتباط با سرور.';
					});
			});

			draw();
		})();
		</script>
		<?php
	}

	/**
	 * Proforma archive table. Public because the employer panel reuses it;
	 * $with_delete is off there, since deleting goes through admin-post.php and
	 * panel-only accounts are intentionally locked out of the back office.
	 */
	public static function render_list( $base, $with_delete = true ) {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT p.*, c.name AS c_name, c.phone AS c_phone FROM ' . self::table_proformas() . ' p LEFT JOIN ' . self::table_customers() . ' c ON c.id = p.customer_id ORDER BY p.id DESC LIMIT 200' ); // phpcs:ignore
		?>
		<style>
			.nptpf-t { width: 100%; border-collapse: collapse; margin-top: 14px; background: #fff; border: 1px solid #dcdcde; }
			.nptpf-t th, .nptpf-t td { border-bottom: 1px solid #f0f0f1; padding: 9px 12px; text-align: right; font-size: 13px; }
			.nptpf-t th { background: #f6f7f7; font-weight: 700; }
			.nptpf-t .num { font-weight: 800; }
			.nptpf-t .acts a { margin-inline-end: 10px; text-decoration: none; }
			.nptpf-t .del { color: #b32d2e; }
			.nptpf-t .src { display: inline-block; padding: 1px 9px; border-radius: 999px; font-size: 11px; font-weight: 700; background: #e7eaf3; color: #3c4a6b; }
			.nptpf-t .src-site { background: #e3f6e9; color: #1a7f37; }
		</style>
		<?php if ( empty( $rows ) ) : ?>
			<?php if ( $with_delete ) : ?>
				<p style="margin-top:16px">هنوز پیش‌فاکتوری ثبت نشده است. از تب «پیش‌فاکتور جدید» اولین پیش‌فاکتور را بسازید.</p>
			<?php else : ?>
				<p style="margin-top:16px">هنوز پیش‌فاکتوری ثبت نشده است. به‌محض اینکه مشتری فرم پیش‌فاکتور سایت را پر کند، اینجا نمایش داده می‌شود.</p>
			<?php endif; ?>
		<?php else : ?>
		<table class="nptpf-t">
			<thead>
				<tr>
					<th>شماره</th>
					<th>منبع</th>
					<th>مشتری</th>
					<th>موبایل</th>
					<th>جمع کل</th>
					<th>تاریخ</th>
					<th>عملیات</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $rows as $r ) : ?>
				<tr>
					<td class="num"><?php echo esc_html( npt_to_persian_digits( (string) $r->number ) ); ?></td>
					<?php $from_site = isset( $r->source ) && 'site' === $r->source; ?>
					<td><span class="src <?php echo $from_site ? 'src-site' : ''; ?>"><?php echo $from_site ? 'سایت' : 'پیشخوان'; ?></span></td>
					<td><?php echo esc_html( $r->c_name ? $r->c_name : '—' ); ?></td>
					<td dir="ltr"><?php echo esc_html( $r->c_phone ? npt_to_persian_digits( $r->c_phone ) : '—' ); ?></td>
					<td><?php echo esc_html( npt_format_price( $r->total, true ) ); ?></td>
					<td><?php echo esc_html( npt_format_date( $r->created_at ) ); ?></td>
					<td class="acts">
						<a href="<?php echo esc_url( add_query_arg( array( 'action' => 'npt_proforma_print', 'token' => $r->token ), admin_url( 'admin-ajax.php' ) ) ); ?>" target="_blank">مشاهده / چاپ</a>
						<?php if ( $with_delete ) : ?>
						<a class="del" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'npt_proforma_delete', 'id' => $r->id ), admin_url( 'admin-post.php' ) ), 'npt_pf_del_' . $r->id ) ); ?>" onclick="return confirm('این پیش‌فاکتور برای همیشه حذف می‌شود. ادامه می‌دهید؟');">حذف</a>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p style="margin-top:8px"><?php echo esc_html( sprintf( 'نمایش آخرین %d پیش‌فاکتور (از جدید به قدیم).', count( $rows ) ) ); ?></p>
		<p class="description" style="margin-top:4px">برچسب «سایت» یعنی پیش‌فاکتور را خود بازدیدکننده از طریق فرم عمومی (شورت‌کد <code>[navid_proforma]</code>) ثبت کرده است؛ «پیشخوان» یعنی در همین بخش ساخته شده.</p>
		<?php endif; ?>
		<?php
	}

	private static function render_customers( $base ) {
		global $wpdb;
		$t1 = self::table_customers();
		$t2 = self::table_proformas();
		$rows = $wpdb->get_results( "SELECT c.*, (SELECT COUNT(*) FROM $t2 p WHERE p.customer_id = c.id) AS pf_count, (SELECT MAX(p.created_at) FROM $t2 p WHERE p.customer_id = c.id) AS pf_last FROM $t1 c ORDER BY c.id DESC LIMIT 300" ); // phpcs:ignore
		?>
		<style>
			.nptpf-c { width: 100%; border-collapse: collapse; margin-top: 14px; background: #fff; border: 1px solid #dcdcde; }
			.nptpf-c th, .nptpf-c td { border-bottom: 1px solid #f0f0f1; padding: 9px 12px; text-align: right; font-size: 13px; }
			.nptpf-c th { background: #f6f7f7; font-weight: 700; }
		</style>
		<?php if ( empty( $rows ) ) : ?>
			<p style="margin-top:16px">آرشیو مشتریان خالی است؛ با ثبت اولین پیش‌فاکتور، مشخصات مشتری اینجا ذخیره می‌شود.</p>
		<?php else : ?>
		<table class="nptpf-c">
			<thead>
				<tr>
					<th>نام</th>
					<th>موبایل</th>
					<th>شرکت / فروشگاه</th>
					<th>ایمیل</th>
					<th>آدرس</th>
					<th>تعداد پیش‌فاکتور</th>
					<th>آخرین پیش‌فاکتور</th>
					<th>عملیات</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $rows as $r ) : ?>
				<tr>
					<td><?php echo esc_html( $r->name ); ?></td>
					<td dir="ltr"><?php echo esc_html( npt_to_persian_digits( $r->phone ) ); ?></td>
					<td><?php echo esc_html( $r->company ? $r->company : '—' ); ?></td>
					<td dir="ltr"><?php echo esc_html( $r->email ? $r->email : '—' ); ?></td>
					<td><?php echo esc_html( $r->address ? wp_trim_words( $r->address, 8, '…' ) : '—' ); ?></td>
					<td><?php echo esc_html( npt_to_persian_digits( (string) $r->pf_count ) ); ?></td>
					<td><?php echo esc_html( $r->pf_last ? npt_format_date( $r->pf_last ) : '—' ); ?></td>
					<td><a href="<?php echo esc_url( add_query_arg( array( 'pf_tab' => 'new', 'customer' => $r->id ), admin_url( 'admin.php?page=' . self::SLUG ) ) ); ?>">پیش‌فاکتور جدید</a></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif;
	}

	/* ---------------------------------------------------------------------
	 * Delete a proforma (customer stays archived)
	 * ------------------------------------------------------------------- */
	public static function handle_delete() {
		if ( ! npt_current_user_can_edit() ) {
			wp_die( esc_html__( 'دسترسی لازم برای این عملیات را ندارید.', 'navid-price-table' ) );
		}
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		check_admin_referer( 'npt_pf_del_' . $id );
		if ( $id ) {
			global $wpdb;
			$wpdb->delete( self::table_proformas(), array( 'id' => $id ), array( '%d' ) );
		}
		wp_safe_redirect( add_query_arg( array( 'page' => self::SLUG, 'pf_tab' => 'list' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Public print view (token-gated, standalone HTML like the online view)
	 * ------------------------------------------------------------------- */
	public static function render_print() {
		$token = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : '';
		if ( ! preg_match( '/^[0-9a-f]{32}$/', $token ) || ! npt_pdf_rate_limit_ok( 'print' ) ) {
			status_header( 403 );
			echo esc_html__( 'لینک پیش‌فاکتور معتبر نیست یا تعداد درخواست‌ها بیش از حد مجاز است.', 'navid-price-table' ); // phpcs:ignore
			exit;
		}

		$key  = 'npt_pf_' . md5( $token . '|' . NPT_VERSION );
		$html = get_transient( $key );
		if ( false === $html ) {
			$html = self::build_print_html( $token );
			if ( null === $html ) {
				status_header( 404 );
				echo esc_html__( 'پیش‌فاکتور یافت نشد.', 'navid-price-table' ); // phpcs:ignore
				exit;
			}
			set_transient( $key, $html, HOUR_IN_SECONDS );
		}

		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		echo $html; // phpcs:ignore
		exit;
	}

	private static function build_print_html( $token ) {
		global $wpdb;
		$p = $wpdb->get_row( $wpdb->prepare(
			'SELECT p.*, c.name AS c_name, c.phone AS c_phone, c.company AS c_company, c.email AS c_email, c.address AS c_address'
			. ' FROM ' . self::table_proformas() . ' p LEFT JOIN ' . self::table_customers() . ' c ON c.id = p.customer_id'
			. ' WHERE p.token = %s LIMIT 1', // phpcs:ignore
			$token
		) );
		if ( ! $p ) {
			return null;
		}

		$items    = json_decode( (string) $p->items, true );
		$logo     = npt_media_image_url( 'npt_logo_id', NPT_URL . 'assets/images/logo-navid.png' );
		$j        = npt_jalali_now();
		$hcss     = vsprintf( '#%02x%02x%02x', npt_header_color_rgb() );
		$acss     = vsprintf( '#%02x%02x%02x', npt_accent_color_rgb() );
		$unit     = npt_currency_word();
		$validity = self::validity_date( $p->validity_days );
		$phone    = trim( (string) get_option( 'npt_phone', '' ) );
		$address  = trim( (string) get_option( 'npt_address', '' ) );
		$i        = 0;

		ob_start();
		?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html( 'پیش‌فاکتور ' . npt_to_persian_digits( (string) $p->number ) . ' - ' . get_bloginfo( 'name' ) ); ?></title>
<style>
	* { box-sizing: border-box; }
	body { margin: 0 auto; max-width: 900px; padding: 16px 18px 40px; background: #f7f9fa; color: #222; font-family: Vazirmatn, Tahoma, Arial, sans-serif; }
	.nptp-print { position: fixed; bottom: 14px; left: 14px; z-index: 9; padding: 8px 14px; border: 1px solid #0f4c5c; border-radius: 8px; background: #0f4c5c; color: #fff; font: inherit; font-size: 13px; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,.25); }
	.nptp-sheet { background: #fff; border: 1px solid #e6e9ec; border-radius: 10px; padding: 20px 22px 26px; }
	.nptp-head { display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; border-bottom: 3px solid <?php echo esc_html( $hcss ); ?>; padding-bottom: 14px; }
	.nptp-head img { height: 64px; }
	.nptp-title h1 { margin: 0; font-size: 24px; color: <?php echo esc_html( $hcss ); ?>; }
	.nptp-meta { color: #555; font-size: 13px; margin-top: 4px; }
	.nptp-meta b { color: <?php echo esc_html( $acss ); ?>; }
	.nptp-cust { margin-top: 16px; border: 1px solid #e0e3e6; border-radius: 8px; padding: 12px 16px; font-size: 13.5px; line-height: 2; background: #fbfcfd; }
	.nptp-cust .t { font-weight: 800; color: <?php echo esc_html( $hcss ); ?>; margin-bottom: 4px; }
	.nptp-cust .g { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 0 18px; }
	table.items { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13px; }
	table.items th, table.items td { border: 1px solid #cfd4d8; padding: 7px 8px; text-align: center; }
	table.items th { background: <?php echo esc_html( $hcss ); ?>; color: #fff; font-weight: 700; }
	table.items .desc { text-align: right; }
	table.items td .nptp-meter-badge { display: inline-block; margin-inline-start: 5px; padding: 0 7px; border-radius: 999px; background: #28a745; color: #fff; font-size: 10px; font-weight: 700; line-height: 1.5; vertical-align: middle; }
	.nptp-sum { margin-top: 14px; max-width: 380px; margin-inline-start: auto; font-size: 14px; }
	.nptp-sum .row { display: flex; justify-content: space-between; padding: 4px 2px; }
	.nptp-sum .grand { font-weight: 800; font-size: 16px; border-top: 2px solid <?php echo esc_html( $hcss ); ?>; margin-top: 6px; padding-top: 8px; }
	.nptp-note { margin-top: 14px; color: #666; font-size: 12.5px; border: 1px dashed #c9ced2; border-radius: 6px; padding: 8px 12px; background: #fbfcfd; }
	.nptp-foot { margin-top: 22px; border-top: 1px solid #e0e3e6; padding-top: 12px; text-align: center; color: #152896; font-weight: 800; font-size: 18px; letter-spacing: 2px; }
	.nptp-foot .contact { display: block; color: #555; font-weight: 400; font-size: 12.5px; letter-spacing: 0; margin-top: 6px; }
	.nptp-sig { display: flex; justify-content: space-between; margin-top: 40px; color: #666; font-size: 12.5px; }
	@media print { .nptp-print { display: none; } body { background: #fff; padding: 0; max-width: none; } .nptp-sheet { border: none; } }
</style>
</head>
<body>
<button type="button" class="nptp-print" onclick="window.print()"><?php esc_html_e( 'چاپ / ذخیره PDF', 'navid-price-table' ); ?></button>
<div class="nptp-sheet">
	<header class="nptp-head">
		<div class="nptp-title">
			<h1>پیش‌فاکتور فروش</h1>
			<div class="nptp-meta">
				شماره: <b><?php echo esc_html( npt_to_persian_digits( (string) $p->number ) ); ?></b>
				&nbsp;|&nbsp; تاریخ: <b><?php echo esc_html( $j['date'] ); ?></b>
				&nbsp;|&nbsp; اعتبار تا: <b><?php echo esc_html( $validity ); ?></b>
			</div>
			<div class="nptp-meta"><?php echo esc_html( npt_unit_sentence() ); ?></div>
		</div>
		<img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
	</header>

	<section class="nptp-cust">
		<div class="t">مشخصات خریدار</div>
		<div class="g">
			<div>نام: <b><?php echo esc_html( $p->c_name ); ?></b></div>
			<div>موبایل: <b dir="ltr"><?php echo esc_html( npt_to_persian_digits( (string) $p->c_phone ) ); ?></b></div>
			<?php if ( $p->c_company ) : ?><div>شرکت / فروشگاه: <?php echo esc_html( $p->c_company ); ?></div><?php endif; ?>
			<?php if ( $p->c_email ) : ?><div>ایمیل: <span dir="ltr"><?php echo esc_html( $p->c_email ); ?></span></div><?php endif; ?>
			<?php if ( $p->c_address ) : ?><div style="grid-column: 1 / -1;">آدرس: <?php echo esc_html( $p->c_address ); ?></div><?php endif; ?>
		</div>
	</section>

	<table class="items">
		<thead>
			<tr>
				<th style="width:36px">#</th>
				<th>شرح کالا</th>
				<th style="width:90px">مقدار</th>
				<th style="width:70px">واحد</th>
				<th style="width:130px">قیمت واحد</th>
				<th style="width:150px">مبلغ کل</th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ( (array) $items as $item ) : $i++; ?>
			<tr>
				<td><?php echo esc_html( npt_to_persian_digits( (string) $i ) ); ?></td>
				<td class="desc"><?php echo esc_html( $item['name'] ); ?><?php if ( ! empty( $item['meter'] ) ) : ?><span class="nptp-meter-badge">متر</span><?php endif; ?></td>
				<td><?php echo esc_html( npt_to_persian_digits( rtrim( rtrim( (string) ( 0 + $item['qty'] ), '0' ), '.' ) ) ); ?></td>
				<td><?php echo esc_html( ! empty( $item['meter'] ) ? __( 'متر', 'navid-price-table' ) : __( 'کلاف', 'navid-price-table' ) ); ?></td>
				<td><?php echo esc_html( npt_format_price( $item['price'] ) ); ?></td>
				<td><?php echo esc_html( npt_format_price( (float) $item['qty'] * (float) $item['price'] ) ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

	<div class="nptp-sum">
		<div class="row"><span>جمع کل</span><span><?php echo esc_html( npt_format_price( $p->subtotal, true ) ); ?></span></div>
		<?php if ( (float) $p->discount > 0 ) : ?>
		<div class="row"><span>تخفیف</span><span><?php echo esc_html( npt_format_price( $p->discount, true ) ); ?></span></div>
		<?php endif; ?>
		<div class="row grand"><span>مبلغ قابل پرداخت</span><span><?php echo esc_html( npt_format_price( $p->total, true ) ); ?></span></div>
	</div>

	<?php if ( trim( (string) $p->note ) ) : ?>
	<div class="nptp-note"><?php echo esc_html( $p->note ); ?></div>
	<?php endif; ?>

	<div class="nptp-sig">
		<span>امضای فروشنده: ....................</span>
		<span>امضای خریدار: ....................</span>
	</div>

	<footer class="nptp-foot">
		<?php echo esc_html( npt_footer_domain_text() ); ?>
		<?php if ( $phone || $address ) : ?>
		<span class="contact"><?php echo esc_html( trim( $address . ( $address && $phone ? '  |  ' : '' ) . $phone ) ); ?></span>
		<?php endif; ?>
	</footer>
</div>
</body>
</html>
		<?php
		return ob_get_clean();
	}
}

NPT_Proforma::init();
