<?php
/**
 * Business panel (پنل مدیر کسب و کار).
 *
 * A stand-alone, mobile-first dashboard for the employer, deliberately living
 * OUTSIDE wp-admin: the site owner asked for a modern panel with access to this
 * section only, not a WooCommerce «My Account» tab and not a shop-manager
 * back office.
 *
 * How the access model works, and why:
 *   - a dedicated role (npt_business_manager) with one custom capability
 *     (npt_manage_panel) is created; administrator / shop_manager get the same
 *     capability so existing accounts can open the panel immediately;
 *   - authentication produces a real WordPress session (password form or OTP),
 *     so every pre-existing npt_current_user_can_edit() gate keeps protecting
 *     the price edit, proforma and SMS endpoints — nothing new can bypass them;
 *   - the panel page is a normal WP page holding the [navid_panel] shortcode,
 *     which keeps the theme chrome (Cando), permalinks and page cache behaving
 *     and needs no custom rewrite rule. The page is created on upgrade and the
 *     URL is therefore secret-free but guessable — hence the wp-admin lockdown
 *     and the login rate limit.
 *   - accounts with the panel capability but no back-office capability are
 *     redirected away from wp-admin and get no admin bar, so the panel really
 *     is the only place they can work.
 *
 * The panel reuses the existing renderers (proforma archive, price table,
 * bulk-SMSTab) instead of duplicating them, so a change in one place shows up
 * in both places.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NPT_Panel {

	const ROLE         = 'npt_business_manager';
	const ROLE_LABEL   = 'مدیر کسب و کار';
	const CAP          = 'npt_manage_panel';
	const NONCE        = 'npt_panel';
	const PAGE_OPT     = 'npt_panel_page';
	const INSTALL_OPT  = 'npt_panel_ver';
	const LOGIN_LIMIT  = 8;

	public static function init() {
		add_shortcode( 'navid_panel', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_ajax_npt_panel_login', array( __CLASS__, 'ajax_login' ) );
		// Bound to wp_ajax_* only: binding a number needs a signed-in panel account.
		add_action( 'wp_ajax_npt_bind_send', array( __CLASS__, 'ajax_bind_send' ) );
		add_action( 'wp_ajax_npt_bind_done', array( __CLASS__, 'ajax_bind_done' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_install' ) );
		add_action( 'template_redirect', array( __CLASS__, 'handle_request' ), 2 );
		add_action( 'admin_init', array( __CLASS__, 'lock_admin' ) );
		add_filter( 'show_admin_bar', array( __CLASS__, 'filter_admin_bar' ) );
		add_filter( 'wp_headers', array( __CLASS__, 'filter_nocache_header' ) );
		add_filter( 'login_redirect', array( __CLASS__, 'filter_login_redirect' ), 10, 3 );
	}

	/* ---------------------------------------------------------------------
	 * Install: role, capability, panel page
	 * ------------------------------------------------------------------- */
	public static function maybe_install() {
		if ( (string) get_option( self::INSTALL_OPT, '' ) === NPT_VERSION ) {
			return;
		}
		self::install();
		update_option( self::INSTALL_OPT, NPT_VERSION, false );
	}

	public static function install() {
		if ( ! get_role( self::ROLE ) ) {
			add_role( self::ROLE, self::ROLE_LABEL, array(
				'read'            => true,
				self::CAP         => true,
			) );
		}
		foreach ( array( 'administrator', 'shop_manager', 'editor' ) as $slug ) {
			$role = get_role( $slug );
			if ( $role && ! $role->has_cap( self::CAP ) ) {
				$role->add_cap( self::CAP );
			}
		}
		self::ensure_page();
	}

	/** Create the panel page once, or adopt an existing page that has the shortcode. */
	public static function ensure_page() {
		$id = (int) get_option( self::PAGE_OPT, 0 );
		if ( $id && 'page' === get_post_type( $id ) && 'trash' !== get_post_status( $id ) ) {
			return $id;
		}

		$found = get_posts( array(
			'post_type'   => 'page',
			'post_status' => 'publish,draft',
			'search'      => '[navid_panel]',
			'number'      => 1,
			'fields'      => 'IDs',
		) );
		if ( $found ) {
			update_option( self::PAGE_OPT, (int) $found[0], false );
			return (int) $found[0];
		}

		$new_id = wp_insert_post( array(
			'post_title'   => 'پنل مدیر کسب و کار',
			'post_name'    => 'panel',
			'post_content' => '[navid_panel]',
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'ping_status'  => 'closed',
			'to_ping'      => '',
		) );
		if ( is_wp_error( $new_id ) ) {
			return 0;
		}
		update_option( self::PAGE_OPT, (int) $new_id, false );
		// The slug may have been taken, in which case permalinks must be rebuilt
		// before /panel/ resolves.
		flush_rewrite_rules( false );
		return (int) $new_id;
	}

	public static function panel_page_id() {
		$id = (int) get_option( self::PAGE_OPT, 0 );
		return $id ? $id : self::ensure_page();
	}

	public static function panel_url() {
		$id  = self::panel_page_id();
		$url = $id ? get_permalink( $id ) : '';
		return $url ? $url : home_url( '/' );
	}

	/* ---------------------------------------------------------------------
	 * Capability helpers
	 * ------------------------------------------------------------------- */
	public static function user_can_panel() {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		return current_user_can( self::CAP ) || current_user_can( 'manage_woocommerce' );
	}

	/** Panel-only accounts: allowed in the dashboard, not in wp-admin. */
	public static function is_panel_only( $user = null ) {
		if ( ! $user instanceof WP_User ) {
			$user = wp_get_current_user();
		}
		if ( ! $user || ! $user->exists() ) {
			return false;
		}
		return $user->has_cap( self::CAP )
			&& ! $user->has_cap( 'manage_options' )
			&& ! $user->has_cap( 'manage_woocommerce' )
			&& ! $user->has_cap( 'edit_posts' );
	}

	public static function filter_admin_bar( $show ) {
		return self::is_panel_only() ? false : $show;
	}

	/** The number already attached to an account, in the shape OTP login reads. */
	public static function user_mobile( WP_User $user ) {
		if ( ! $user->exists() ) {
			return '';
		}
		foreach ( array( 'npt_mobile', 'billing_phone', 'billing_mobile' ) as $meta_key ) {
			$phone = NPT_Proforma::normalize_phone( (string) get_user_meta( $user->ID, $meta_key, true ) );
			if ( $phone ) {
				return $phone;
			}
		}
		return '';
	}

	/** The account that owns a number, or false. Same meta order as NPT_OTP. */
	private static function user_by_mobile( $phone ) {
		if ( ! $phone ) {
			return false;
		}
		foreach ( array( 'npt_mobile', 'billing_phone', 'billing_mobile' ) as $meta_key ) {
			$ids = get_users( array(
				'meta_key'    => $meta_key,
				'meta_value'  => $phone,
				'number'      => 1,
				'count_total' => false,
				'fields'      => 'ID',
			) );
			if ( $ids ) {
				$user = get_user_by( 'id', (int) $ids[0] );
				if ( $user ) {
					return $user;
				}
			}
		}
		return false;
	}

	/**
	 * An employer account is normally created by hand (Users → Add new, role
	 * «مدیر کسب و کار») and therefore has no mobile number, which means the SMS
	 * login cannot resolve it. Rather than telling the owner "call me", the panel
	 * asks the signed-in account to prove ownership of a number with an OTP
	 * (scene=bind, so neither a login code nor a registration code can be
	 * replayed here) and stores it on that same account.
	 */
	private static function needs_bind() {
		if ( '' !== self::user_mobile( wp_get_current_user() ) ) {
			return false;
		}
		// Accounts that can edit users already have their number in the profile.
		if ( current_user_can( 'edit_users' ) ) {
			return false;
		}
		return NPT_OTP::enabled() && NPT_SMS::otp_ready();
	}

	public static function lock_admin() {
		if ( wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		if ( ! self::is_panel_only() ) {
			return;
		}
		wp_safe_redirect( self::panel_url() );
		exit;
	}

	/** wp-login.php after a panel-only login must land on the panel, not the dashboard. */
	public static function filter_login_redirect( $redirect_to, $requested, $user ) {
		if ( $user instanceof WP_User && self::is_panel_only( $user ) ) {
			return self::panel_url();
		}
		return $redirect_to;
	}

	public static function filter_nocache_header( $headers ) {
		if ( is_page( self::panel_page_id() ) ) {
			// The page holds a nonce and a login form; a cached copy would hand the
			// next visitor an expired nonce.
			$headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0';
			$headers['Pragma']        = 'no-cache';
		}
		return $headers;
	}

	/* ---------------------------------------------------------------------
	 * POST / logout, handled before any output so redirects work
	 * ------------------------------------------------------------------- */
	public static function handle_request() {
		if ( isset( $_GET['npt_action'] ) && 'logout' === $_GET['npt_action'] ) {
			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
			if ( wp_verify_nonce( $nonce, 'npt_panel_logout' ) ) {
				wp_logout();
				wp_safe_redirect( self::panel_url() );
				exit;
			}
		}

		if ( 'POST' === strtoupper( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) && isset( $_POST['npt_panel_form'] ) ) {
			self::handle_post();
		}
	}

	private static function handle_post() {
		$form = isset( $_POST['npt_panel_form'] ) ? sanitize_key( wp_unslash( $_POST['npt_panel_form'] ) ) : '';
		check_admin_referer( self::NONCE . '_' . $form );

		$back = self::panel_url();
		if ( ! self::user_can_panel() ) {
			wp_safe_redirect( $back );
			exit;
		}

		if ( 'quick' === $form ) {
			$settings         = NPT_Bar::settings();
			$incoming         = isset( $_POST['npt_bar_settings'] ) && is_array( $_POST['npt_bar_settings'] ) ? wp_unslash( $_POST['npt_bar_settings'] ) : array();
			$allowed          = array( 'call_number', 'call_label', 'whatsapp_number', 'whatsapp_label', 'telegram_url', 'telegram_label', 'whatsapp_icon_url', 'call_icon_url', 'telegram_icon_url', 'popup_title', 'popup_subtitle', 'enable_call', 'enable_whatsapp', 'enable_telegram', 'enable_custom', 'custom_links' );
			foreach ( $allowed as $key ) {
				if ( array_key_exists( $key, $incoming ) ) {
					$settings[ $key ] = $incoming[ $key ];
				}
			}
			update_option( 'npt_bar_settings', NPT_Bar::sanitize( $settings ), false );
			npt_bump_table_cache_version();
			wp_safe_redirect( add_query_arg( 'npt_msg', 'saved', $back ) );
			exit;
		}

		wp_safe_redirect( $back );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Password login (AJAX, rate limited, mobile / email / username accepted)
	 * ------------------------------------------------------------------- */
	public static function ajax_login() {
		if ( ! check_ajax_referer( self::NONCE, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'نشست شما منقضی شده است. صفحه را تازه کنید و دوباره تلاش کنید.' ), 403 );
		}
		$key  = 'npt_login_' . substr( hash_hmac( 'sha256', npt_client_ip(), wp_salt( 'auth' ) ), 0, 32 );
		$hits = absint( get_transient( $key ) );
		if ( $hits >= self::LOGIN_LIMIT ) {
			wp_send_json_error( array( 'message' => 'تلاش‌های ناموفق زیاد بود. ۱۵ دقیقه صبر کنید.' ), 429 );
		}

		$identity = sanitize_text_field( wp_unslash( isset( $_POST['identity'] ) ? $_POST['identity'] : '' ) );
		$password = (string) wp_unslash( isset( $_POST['password'] ) ? $_POST['password'] : '' );
		$remember = ! empty( $_POST['remember'] );

		$login  = $identity;
		$maybe  = NPT_Proforma::normalize_phone( $identity );
		if ( $maybe ) {
			$ids = get_users( array(
				'meta_key'    => 'npt_mobile',
				'meta_value'  => $maybe,
				'number'      => 1,
				'count_total' => false,
				'fields'      => 'ID',
			) );
			if ( ! $ids ) {
				$ids = get_users( array(
					'meta_key'    => 'billing_phone',
					'meta_value'  => $maybe,
					'number'      => 1,
					'count_total' => false,
					'fields'      => 'ID',
				) );
			}
			$found = $ids ? get_user_by( 'id', (int) $ids[0] ) : false;
			$login = $found ? $found->user_login : '';
		}

		$user = '' === $login ? null : wp_authenticate( $login, $password );
		if ( ! $user || is_wp_error( $user ) ) {
			set_transient( $key, $hits + 1, 15 * MINUTE_IN_SECONDS );
			wp_send_json_error( array( 'message' => 'نام کاربری/شماره یا رمز عبور درست نیست.' ), 401 );
		}
		if ( ! self::panel_user_allowed( $user ) ) {
			// Same answer as a wrong password: don't confirm that the account exists.
			set_transient( $key, $hits + 1, 15 * MINUTE_IN_SECONDS );
			wp_send_json_error( array( 'message' => 'نام کاربری/شماره یا رمز عبور درست نیست.' ), 401 );
		}

		delete_transient( $key );
		NPT_OTP::login( $user );
		wp_send_json_success( array( 'message' => 'ورود موفق.', 'reload' => true ) );
	}

	/** Only the panel capability, or a real shop manager / admin, may use the panel. */
	private static function panel_user_allowed( WP_User $user ) {
		return $user->has_cap( self::CAP ) || $user->has_cap( 'manage_woocommerce' );
	}

	/* ---------------------------------------------------------------------
	 * Bind my number (scene=bind OTP)
	 * ------------------------------------------------------------------- */
	public static function ajax_bind_send() {
		self::bind_guard();
		$phone = NPT_Proforma::normalize_phone( isset( $_POST['phone'] ) ? wp_unslash( $_POST['phone'] ) : '' );
		if ( ! $phone ) {
			wp_send_json_error( array( 'message' => 'شماره موبایل معتبر نیست.' ), 400 );
		}
		self::number_is_free( $phone );
		// The OTP sender keeps its own nonce/limits/credentials logic; only the
		// scene differs, and scene is compared with hash_equals on verify.
		$_POST['scene'] = 'bind';
		NPT_OTP::ajax_send();
	}

	public static function ajax_bind_done() {
		self::bind_guard();
		if ( ! check_ajax_referer( NPT_OTP::NONCE, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'نشست شما منقضی شده است. صفحه را تازه کنید و دوباره تلاش کنید.' ), 403 );
		}
		$phone = NPT_Proforma::normalize_phone( isset( $_POST['phone'] ) ? wp_unslash( $_POST['phone'] ) : '' );
		$code  = isset( $_POST['code'] ) ? (string) wp_unslash( $_POST['code'] ) : '';

		$verified = NPT_OTP::verify_code( $phone, $code, 'bind' );
		if ( is_wp_error( $verified ) ) {
			wp_send_json_error( array( 'message' => $verified->get_error_message() ), self::bind_status( $verified ) );
		}
		self::number_is_free( $verified );

		$user = wp_get_current_user();
		// billing_phone as well, so WooCommerce/Cando order forms and any future
		// code that reads the shop field find the same number.
		update_user_meta( $user->ID, 'npt_mobile', $verified );
		update_user_meta( $user->ID, 'billing_phone', $verified );
		wp_send_json_success( array( 'message' => 'شماره ذخیره شد. از این به بعد می‌توانید با کد پیامکی وارد شوید.', 'reload' => true ) );
	}

	private static function bind_guard() {
		if ( ! is_user_logged_in() || ! self::user_can_panel() ) {
			wp_send_json_error( array( 'message' => 'این کار فقط برای حساب وارد‌شده‌ی دارای پنل ممکن است.' ), 403 );
		}
	}

	/** A number that belongs to a different account must never be adopted. */
	private static function number_is_free( $phone ) {
		$owner = self::user_by_mobile( $phone );
		if ( $owner && (int) $owner->ID !== (int) get_current_user_id() ) {
			wp_send_json_error( array( 'message' => 'این شماره روی حساب دیگری ثبت شده است.' ), 409 );
		}
	}

	private static function bind_status( WP_Error $error ) {
		$data = $error->get_error_data();
		return is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 400;
	}

	/* ---------------------------------------------------------------------
	 * Shortcode entry point
	 * ------------------------------------------------------------------- */
	public static function shortcode( $atts = array() ) {
		self::maybe_install();
		nocache_headers();
		ob_start();
		if ( self::user_can_panel() ) {
			self::render_dashboard();
		} else {
			self::render_login();
		}
		// The script queries the DOM as soon as it parses, so it has to come after
		// the markup rather than in the head.
		self::render_assets();
		return (string) ob_get_clean();
	}

	/* ---------------------------------------------------------------------
	 * Panel stylesheet / script (inline, only on the panel page)
	 * ------------------------------------------------------------------- */
	public static function render_assets() {
		$head     = vsprintf( '#%02x%02x%02x', npt_header_color_rgb() );
		$accent   = vsprintf( '#%02x%02x%02x', npt_accent_color_rgb() );
		$cooldown = 60;
		?>
		<style id="npt-panel-css">
		@font-face{font-family:'NPTPnlVazir';src:url('<?php echo esc_url( NPT_URL ); ?>vendor/fonts/Vazirmatn-Regular.ttf') format('truetype');font-weight:400;font-style:normal;font-display:swap}
		@font-face{font-family:'NPTPnlVazir';src:url('<?php echo esc_url( NPT_URL ); ?>vendor/fonts/Vazirmatn-Bold.ttf') format('truetype');font-weight:700;font-style:normal;font-display:swap}
		.nptp{--pnl-head:<?php echo esc_html( $head ); ?>;--pnl-accent:<?php echo esc_html( $accent ); ?>;direction:rtl;font-family:'NPTPnlVazir',Tahoma,Arial,sans-serif;color:#1c2430;max-width:1120px;margin:0 auto;padding:16px 12px;font-size:14.5px;line-height:1.85}
		.nptp *,.nptp *:before,.nptp *:after{box-sizing:border-box}
		.nptp img{max-width:100%;height:auto}
		.nptp-auth-wrap{display:flex;justify-content:center;padding:24px 0}
		.nptp-auth{width:100%;max-width:430px;background:#fff;border:1px solid #eef1f6;border-radius:18px;box-shadow:0 12px 32px rgba(20,30,50,.10);padding:22px}
		.nptp-brand{display:flex;gap:12px;align-items:center;margin-bottom:18px}
		.nptp-brand-mark{width:44px;height:44px;border-radius:14px;background:var(--pnl-head);color:#fff;display:flex;align-items:center;justify-content:center;font-size:20px;flex:none}
		.nptp-brand strong{display:block;font-size:17px;font-weight:700}
		.nptp-brand em{font-style:normal;font-size:12.5px;color:#68788f}
		.nptp-seg{display:flex;background:#f2f5fa;border-radius:12px;padding:4px;margin-bottom:16px;gap:4px}
		.nptp-seg-btn{flex:1;border:0;background:transparent;padding:9px 6px;border-radius:9px;font:inherit;font-weight:700;font-size:13.5px;color:#5a6b83;cursor:pointer}
		.nptp-seg-btn.is-active{background:#fff;color:var(--pnl-head);box-shadow:0 1px 6px rgba(20,30,50,.12)}
		.nptp-seg-btn:disabled{opacity:.45;cursor:not-allowed}
		.nptp-form label,.nptp-bind label{display:block;font-size:13px;font-weight:600;margin-bottom:14px;color:#3a4658}
		.nptp-form input,.nptp-bind input{display:block;width:100%;margin-top:6px;padding:11px 12px;border:1px solid #dbe2ec;border-radius:11px;font:inherit;font-size:15px;background:#fbfcfe;color:inherit}
		.nptp-form input:focus,.nptp-bind input:focus{outline:0;border-color:var(--pnl-head);background:#fff}
		.nptp-check{display:flex;align-items:center;gap:8px}
		.nptp-check input{width:auto;margin:0}
		.nptp-btn{width:100%;border:0;border-radius:12px;background:var(--pnl-head);color:#fff;padding:12px;font:inherit;font-weight:700;font-size:15px;cursor:pointer}
		.nptp-btn:disabled{opacity:.6;cursor:progress}
		.nptp-btn.is-ghost{background:#fff;color:var(--pnl-head);border:1px solid #dbe2ec;width:auto;padding:9px 18px}
		.nptp-link{background:none;border:0;color:var(--pnl-accent);font:inherit;font-size:13px;font-weight:700;cursor:pointer;padding:0;margin-top:6px;display:inline-block}
		.nptp-link:disabled{color:#9aa7b8;cursor:not-allowed}
		.nptp-back{display:inline-block;font-size:12.5px;color:#68788f;background:none;border:0;font-family:inherit;cursor:pointer;padding:0;margin-bottom:10px}
		.nptp-status{min-height:22px;font-size:13.5px;font-weight:700;margin:12px 0 0;color:#b3261e}
		.nptp-status.is-ok{color:#127a3c}
		.nptp-note{background:#f4f7fd;border:1px solid #e2eaf8;color:#3a4658;font-size:13px;padding:10px 12px;border-radius:11px;margin:0 0 14px}
		.nptp-note.is-ok{background:#eefaf1;border-color:#c8ecd4;color:#127a3c}
		.nptp-foot{font-size:13px;margin:14px 0 0}
		.nptp-foot.muted{color:#68788f;font-size:12px;line-height:1.7}
		.nptp-head{display:flex;justify-content:space-between;align-items:center;gap:10px;background:var(--pnl-head);color:#fff;border-radius:16px;padding:14px 18px}
		.nptp-head-id strong{display:block;font-size:16px}
		.nptp-head-id em{font-style:normal;font-size:12.5px;opacity:.85}
		.nptp-logout{color:#fff;background:rgba(255,255,255,.16);padding:8px 14px;border-radius:10px;font-size:13px;font-weight:700;text-decoration:none;white-space:nowrap}
		.nptp-tabs{display:flex;gap:8px;overflow-x:auto;margin:14px 0;padding-bottom:4px;-webkit-overflow-scrolling:touch}
		.nptp-tab{white-space:nowrap;padding:9px 16px;border-radius:999px;background:#fff;border:1px solid #e3e8f1;font-size:13.5px;font-weight:700;color:#4a5a72;text-decoration:none}
		.nptp-tab.is-active{background:var(--pnl-head);border-color:var(--pnl-head);color:#fff}
		.nptp-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:14px}
		.nptp-stat{background:#fff;border:1px solid #e6ebf3;border-radius:14px;padding:14px 16px}
		.nptp-stat span{display:block;font-size:12.5px;color:#68788f}
		.nptp-stat strong{display:block;font-size:18px;margin:5px 0 2px;color:var(--pnl-head);font-weight:800}
		.nptp-stat em{font-style:normal;font-size:11.5px;color:#8796ab}
		.nptp-hint{font-size:12.5px;color:#68788f;background:#f7f9fc;border-radius:10px;padding:9px 12px}
		.nptp-box{background:#fff;border:1px solid #e6ebf3;border-radius:14px;padding:16px;margin-bottom:14px}
		.nptp-box h3{margin:0 0 14px;font-size:15px;font-weight:800}
		.nptp-box select{width:100%;max-width:340px;padding:9px 10px;border:1px solid #dbe2ec;border-radius:10px;font:inherit;font-size:14px;background:#fff}
		.nptp-box textarea{width:100%;padding:10px 12px;border:1px solid #dbe2ec;border-radius:10px;font:inherit;font-size:14px}
		.nptp-quick label{display:block;font-size:13px;font-weight:600;margin-bottom:14px;color:#3a4658}
		.nptp-quick input[type=text],.nptp-quick input[type=tel],.nptp-quick input[type=url]{display:block;width:100%;max-width:420px;margin-top:5px;padding:10px 12px;border:1px solid #dbe2ec;border-radius:10px;font:inherit;font-size:14.5px}
		.nptp-quick .nptp-check{font-weight:600;margin-bottom:14px}
		.nptp-quick .nptp-check input{width:auto;margin-inline-end:8px}
		.nptp .nptss,.nptp .nptpf-t{margin-top:0}
		.nptp .nptss-box,.nptp .nptpf-t{background:#fff;border:1px solid #e6ebf3;border-radius:14px;overflow:hidden}
		.nptp .nptss-box{padding:16px;margin-bottom:14px}
		.nptp .nptss label,.nptp .nptp-quick,.nptp .nptss textarea{margin-bottom:12px}
		.nptp .nptss textarea{width:100%}
		.nptp .nptss select{padding:9px 10px;border:1px solid #dbe2ec;border-radius:10px;font:inherit;background:#fff}
		.nptp .nptss input[type=text]{padding:9px 10px;border:1px solid #dbe2ec;border-radius:10px;font:inherit}
		.nptp .nptpf-t{width:100%;border-collapse:separate;border-spacing:0}
		.nptp .nptpf-t th,.nptp .nptpf-t td{border-bottom:1px solid #eef1f6;padding:10px 12px;text-align:right;font-size:13px}
		.nptp .nptpf-t th{background:#f6f8fc;font-weight:700}
		.nptp .button,.nptp .nptss .button{display:inline-block;background:#fff;border:1px solid #d5dce7;border-radius:10px;padding:8px 14px;font-size:13.5px;font-weight:600;cursor:pointer;color:#2c3a4f;text-decoration:none;font-family:inherit;line-height:1.6}
		.nptp .button-primary{background:var(--pnl-head);border-color:var(--pnl-head);color:#fff}
		@media (max-width:600px){.nptp{padding:10px 4px}.nptp-auth{padding:18px;border-radius:14px}.nptp-head{padding:12px 14px;border-radius:12px}.nptp-stat strong{font-size:16px}}
		</style>
		<script>
		(function () {
			var wrap = document.querySelector('.nptp');
			if (! wrap) { return; }
			var ajax = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
			var nonce = <?php echo wp_json_encode( wp_create_nonce( self::NONCE ) ); ?>;
			var otpNonce = <?php echo wp_json_encode( wp_create_nonce( NPT_OTP::NONCE ) ); ?>;
			var cooldownSeconds = <?php echo (int) $cooldown; ?>;
			var statusEl = wrap.querySelector('.nptp-status');
			var timer = null;
			// True between "code sent" and "code entered/aborted": the OTP mode has
			// two forms (request + verify) and only one of them may be visible.
			var codeSent = false;
			function setStatus(text, ok) {
				if (!statusEl) { return; }
				statusEl.textContent = text || '';
				statusEl.className = 'nptp-status' + (ok ? ' is-ok' : '');
			}
			function post(action, data, cb, which) {
				var fd = new FormData();
				Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
				fd.append('action', action);
				fd.append('nonce', which === 'otp' ? otpNonce : nonce);
				fetch(ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(cb)
					.catch(function () { setStatus('ارتباط با سرور برقرار نشد. دوباره تلاش کنید.'); });
			}
			function msg(res, fallback) {
				return (res && res.data && res.data.message) ? res.data.message : fallback;
			}
			function otpPost(action, data, cb) { return post(action, data, cb, 'otp'); }
			function tick(btn) {
				var left = cooldownSeconds, span = btn.querySelector('span');
				btn.disabled = true;
				if (span) { span.textContent = left; }
				clearInterval(timer);
				timer = setInterval(function () {
					left -= 1;
					if (span) { span.textContent = left; }
					if (left <= 0) { clearInterval(timer); btn.disabled = false; }
				}, 1000);
			}

			/* mode switch */
			var segs = wrap.querySelectorAll('.nptp-seg-btn');
			var forms = wrap.querySelectorAll('.nptp-form');
			function showMode(mode) {
				Array.prototype.forEach.call(segs, function (b) { b.classList.toggle('is-active', b.getAttribute('data-mode') === mode); });
				Array.prototype.forEach.call(forms, function (f) {
					if (f.getAttribute('data-mode') !== mode) { f.hidden = true; return; }
					f.hidden = (f === codeForm) ? !codeSent : codeSent;
				});
				setStatus('');
			}
			Array.prototype.forEach.call(segs, function (b) {
				b.addEventListener('click', function () { if (!b.disabled) { showMode(b.getAttribute('data-mode')); } });
			});

			/* OTP */
			var sendForm = wrap.querySelector('#nptp-otp-send');
			var codeForm = wrap.querySelector('#nptp-otp-code');
			if (sendForm && codeForm) {
				var phoneIn = sendForm.querySelector('[name=phone]');
				sendForm.addEventListener('submit', function (e) {
					e.preventDefault();
					var btn = sendForm.querySelector('button[type=submit]');
					btn.disabled = true;
					otpPost('npt_send_otp', { phone: phoneIn.value }, function (res) {
						btn.disabled = false;
						setStatus(msg(res, 'ارسال کد انجام نشد.'), !!res.success);
						if (res && res.success) {
							codeSent = true;
							codeForm.hidden = false;
							sendForm.hidden = true;
							codeForm.querySelector('[name=code]').value = '';
							codeForm.querySelector('[name=code]').focus();
							tick(wrap.querySelector('#nptp-resend'));
						}
					});
				});
				codeForm.addEventListener('submit', function (e) {
					e.preventDefault();
					var btn = codeForm.querySelector('button[type=submit]');
					btn.disabled = true;
					otpPost('npt_verify_otp', { phone: phoneIn.value, code: codeForm.querySelector('[name=code]').value }, function (res) {
						btn.disabled = false;
						setStatus(msg(res, 'بررسی کد انجام نشد.'), !!res.success);
						if (res && res.success) { window.location.reload(); }
					});
				});
				var back = wrap.querySelector('#nptp-otp-back');
				if (back) {
					back.addEventListener('click', function () { codeSent = false; codeForm.hidden = true; sendForm.hidden = false; setStatus(''); });
				}
				var resend = wrap.querySelector('#nptp-resend');
				if (resend) {
					resend.addEventListener('click', function () {
						otpPost('npt_send_otp', { phone: phoneIn.value }, function (res) {
							setStatus(msg(res, ''), !!res.success);
							if (res && res.success) { tick(resend); }
						});
					});
				}
			}

			/* password */
			var passForm = wrap.querySelector('#nptp-pass-form');
			if (passForm) {
				passForm.addEventListener('submit', function (e) {
					e.preventDefault();
					var btn = passForm.querySelector('button[type=submit]');
					btn.disabled = true;
					post('npt_panel_login', {
						identity: passForm.querySelector('[name=identity]').value,
						password: passForm.querySelector('[name=password]').value,
						remember: passForm.querySelector('[name=remember]') ? 1 : ''
					}, function (res) {
						btn.disabled = false;
						setStatus(msg(res, 'ورود انجام نشد.'), !!res.success);
						if (res && res.success) { window.location.reload(); }
					});
				});
			}

			/* registration */
			var regForm = wrap.querySelector('#nptp-reg-form');
			if (regForm) {
				var regStep = regForm.querySelector('.nptp-reg-code');
				regForm.addEventListener('submit', function (e) {
					e.preventDefault();
					var btn = regForm.querySelector('button[type=submit]');
					var action = regStep.hidden ? 'npt_register_send' : 'npt_register_done';
					btn.disabled = true;
					var data = { name: (regForm.querySelector('[name=name]') || {}).value || '', phone: regForm.querySelector('[name=phone]').value };
					if (action === 'npt_register_done') {
						data.code = regForm.querySelector('[name=code]').value;
						data.name = regForm.querySelector('[name=name]').value;
					}
					otpPost(action, data, function (res) {
						btn.disabled = false;
						setStatus(msg(res, 'خطا.'), !!res.success);
						if (res && res.success) {
							if (action === 'npt_register_send') {
								regStep.hidden = false;
								regForm.querySelector('[name=code]').focus();
								tick(regForm.querySelector('.nptp-resend-btn'));
							} else if (res.data && res.data.redirect) {
								window.location.href = res.data.redirect;
							} else {
								window.location.reload();
							}
						}
					});
				});
				var regAgain = regForm.querySelector('.nptp-resend-btn');
				if (regAgain) {
					regAgain.addEventListener('click', function () {
						otpPost('npt_register_send', { name: regForm.querySelector('[name=name]').value, phone: regForm.querySelector('[name=phone]').value }, function (res) {
							setStatus(msg(res, ''), !!res.success);
							if (res && res.success) { tick(regAgain); }
						});
					});
				}
			}
			/* bind my number — dashboard only, same two-step shape as registration */
			var bindForm = wrap.querySelector('#nptp-bind-form');
			if (bindForm) {
				var bindStep = bindForm.querySelector('.nptp-bind-code');
				var bindPhone = bindForm.querySelector('[name=phone]');
				bindForm.addEventListener('submit', function (e) {
					e.preventDefault();
					var btn = bindForm.querySelector('button[type=submit]');
					var action = bindStep.hidden ? 'npt_bind_send' : 'npt_bind_done';
					btn.disabled = true;
					var data = { phone: bindPhone.value };
					if (action === 'npt_bind_done') { data.code = bindForm.querySelector('[name=code]').value; }
					otpPost(action, data, function (res) {
						btn.disabled = false;
						setStatus(msg(res, 'خطا.'), !!res.success);
						if (res && res.success) {
							if (action === 'npt_bind_send') {
								bindStep.hidden = false;
								bindForm.querySelector('[name=code]').focus();
								tick(bindForm.querySelector('.nptp-resend-btn'));
							} else {
								window.location.reload();
							}
						}
					});
				});
				var bindAgain = bindForm.querySelector('.nptp-resend-btn');
				if (bindAgain) {
					bindAgain.addEventListener('click', function () {
						otpPost('npt_bind_send', { phone: bindPhone.value }, function (res) {
							setStatus(msg(res, ''), !!res.success);
							if (res && res.success) { tick(bindAgain); }
						});
					});
				}
			}
		}());
		</script>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Login card
	 * ------------------------------------------------------------------- */
	private static function render_login() {
		$otp_on     = NPT_OTP::enabled() && NPT_SMS::otp_ready();
		$register   = function_exists( 'npt_register_url' ) ? npt_register_url() : '';
		$lost       = wp_lostpassword_url();
		?>
		<div class="nptp nptp-auth-wrap" dir="rtl">
			<div class="nptp-auth">
				<div class="nptp-brand">
					<span class="nptp-brand-mark" aria-hidden="true">▤</span>
					<div>
						<strong>پنل مدیر کسب و کار</strong>
						<em>سیم و کابل نوید</em>
					</div>
				</div>

				<div class="nptp-seg">
					<button type="button" class="nptp-seg-btn <?php echo $otp_on ? 'is-active' : ''; ?>" data-mode="otp" <?php echo $otp_on ? '' : 'disabled'; ?>>کد پیامکی</button>
					<button type="button" class="nptp-seg-btn <?php echo $otp_on ? '' : 'is-active'; ?>" data-mode="pass">رمز عبور</button>
				</div>

				<?php if ( ! $otp_on ) : ?>
					<p class="nptp-note">ورود با کد پیامکی فعلاً غیرفعال است (تنظیمات پنل پیامک در پیشخوان کامل نشده). با رمز عبور وارد شوید.</p>
				<?php endif; ?>

				<form class="nptp-form" data-mode="otp" id="nptp-otp-send" <?php echo $otp_on ? '' : 'hidden'; ?>>
					<label>شماره موبایل
						<input type="tel" name="phone" inputmode="numeric" autocomplete="tel" maxlength="11" placeholder="09123456789" required>
					</label>
					<button type="submit" class="nptp-btn">ارسال کد</button>
				</form>

				<form class="nptp-form" data-mode="otp" id="nptp-otp-code" hidden>
					<button type="button" class="nptp-back" id="nptp-otp-back">→ تغییر شماره</button>
					<label>کد تأیید
						<input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required>
					</label>
					<button type="submit" class="nptp-btn">ورود</button>
					<button type="button" class="nptp-link" id="nptp-resend" disabled>ارسال مجدد (<span>60</span>)</button>
				</form>

				<form class="nptp-form" data-mode="pass" id="nptp-pass-form" <?php echo $otp_on ? 'hidden' : ''; ?>>
					<label>نام کاربری، ایمیل یا شماره موبایل
						<input type="text" name="identity" autocomplete="username" required>
					</label>
					<label>رمز عبور
						<input type="password" name="password" autocomplete="current-password" required>
					</label>
					<label class="nptp-check"><input type="checkbox" name="remember" value="1" checked> مرا به خاطر بسپار</label>
					<button type="submit" class="nptp-btn">ورود</button>
					<?php if ( $lost ) : ?>
						<button type="button" class="nptp-link" onclick="window.location.href=<?php echo wp_json_encode( $lost ); ?>">رمز عبورم را فراموش کرده‌ام</button>
					<?php endif; ?>
				</form>

				<p class="nptp-status" role="status" aria-live="polite"></p>

				<?php if ( $register ) : ?>
					<p class="nptp-foot">حساب ندارید؟ <a href="<?php echo esc_url( $register ); ?>">ثبت‌نام در سایت</a></p>
				<?php endif; ?>
				<p class="nptp-foot muted">این صفحه فقط «پنل مدیر کسب و کار» را باز می‌کند و ورودی به پیشخوان وردپرس نیست.</p>
			</div>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Dashboard
	 * ------------------------------------------------------------------- */
	private static function render_dashboard() {
		$user = wp_get_current_user();
		$tab  = isset( $_GET['npt_tab'] ) ? sanitize_key( wp_unslash( $_GET['npt_tab'] ) ) : 'proformas'; // phpcs:ignore
		$tabs = array(
			'proformas' => 'پیش‌فاکتورها',
			'prices'    => 'قیمت‌ها',
			'sms'       => 'پیامک',
			'quick'     => 'تنظیمات سریع',
		);
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'proformas';
		}
		$msg = isset( $_GET['npt_msg'] ) ? sanitize_key( wp_unslash( $_GET['npt_msg'] ) ) : ''; // phpcs:ignore
		?>
		<div class="nptp nptp-dash" dir="rtl">
			<header class="nptp-head">
				<div class="nptp-head-id">
					<strong>پنل مدیر کسب و کار</strong>
					<span><?php echo esc_html( $user->display_name ? $user->display_name : $user->user_login ); ?></span>
				</div>
				<a class="nptp-logout" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'npt_action', 'logout', self::panel_url() ), 'npt_panel_logout' ) ); ?>">خروج</a>
			</header>

			<nav class="nptp-tabs">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<a class="nptp-tab <?php echo $key === $tab ? 'is-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'npt_tab', $key, self::panel_url() ) ); ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</nav>

			<?php if ( 'saved' === $msg ) : ?>
				<p class="nptp-note is-ok">تنظیمات ذخیره شد.</p>
			<?php endif; ?>

			<?php if ( self::needs_bind() ) : ?>
				<div class="nptp-box nptp-bind">
					<h3>شماره موبایل برای ورود پیامکی</h3>
					<p class="nptp-hint">این حساب هنوز شماره‌ای ندارد، پس فعلاً فقط با رمز عبور می‌توانید وارد شوید. شماره را وارد و تأیید کنید تا ورود با کد پیامکی هم برایتان فعال شود.</p>
					<form id="nptp-bind-form">
						<label>شماره موبایل
							<input type="tel" name="phone" inputmode="numeric" autocomplete="tel" maxlength="11" placeholder="09123456789" required>
						</label>
						<div class="nptp-bind-code" hidden>
							<label>کد تأیید
								<input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required>
							</label>
							<button type="button" class="nptp-link nptp-resend-btn" disabled>ارسال مجدد (<span>60</span>)</button>
						</div>
						<button type="submit" class="nptp-btn">ارسال کد تأیید</button>
					</form>
					<p class="nptp-status" role="status" aria-live="polite"></p>
				</div>
			<?php endif; ?>

			<?php
			if ( 'prices' === $tab ) {
				self::tab_prices();
			} elseif ( 'sms' === $tab ) {
				self::tab_sms();
			} elseif ( 'quick' === $tab ) {
				self::tab_quick();
			} else {
				self::tab_proformas();
			}
			?>
		</div>
		<?php
	}

	private static function tab_proformas() {
		global $wpdb;
		$table = NPT_Proforma::table_proformas();
		$first = gmdate( 'Y-m-01 00:00:00' );
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" ); // phpcs:ignore
		$month = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE created_at >= %s", $first ) ); // phpcs:ignore
		$sum   = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(total),0) FROM $table WHERE created_at >= %s", $first ) ); // phpcs:ignore
		$cust  = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . NPT_Proforma::table_customers() ); // phpcs:ignore
		?>
		<div class="nptp-stats">
			<div class="nptp-stat"><span>پیش‌فاکتور این ماه</span><strong><?php echo esc_html( npt_to_persian_digits( (string) $month ) ); ?></strong><em><?php echo esc_html( npt_to_persian_digits( (string) $total ) ); ?> در کل</em></div>
			<div class="nptp-stat"><span>مجموع این ماه</span><strong><?php echo esc_html( npt_format_price( $sum, true ) ); ?></strong><em>&nbsp;</em></div>
			<div class="nptp-stat"><span>مشتریان ثبت‌شده</span><strong><?php echo esc_html( npt_to_persian_digits( (string) $cust ) ); ?></strong><em>&nbsp;</em></div>
		</div>
		<p class="nptp-hint">برای دیدن جزئیات یا چاپ هر پیش‌فاکتور روی «مشاهده / چاپ» بزنید. پیش‌فاکتورهایی که بازدیدکننده با فرم سایت ساخته برچسب «سایت» دارند.</p>
		<?php
		NPT_Proforma::render_list( self::panel_url(), false );
	}

	private static function tab_prices() {
		echo '<div class="nptp-prices">';
		echo do_shortcode( '[navid_price_table]' );
		echo '</div>';
		?>
		<p class="nptp-hint">قیمت‌ها را همان‌طور که در سایت می‌بینید با آیکن مداد تغییر دهید؛ ذخیره‌ی همان‌جا است و در PDF و جدول سایت فوری اعمال می‌شود.</p>
		<?php
	}

	private static function tab_sms() {
		if ( ! class_exists( 'NPT_SMS' ) ) {
			echo '<p>بخش پیامک در دسترس نیست.</p>';
			return;
		}
		echo '<p class="nptp-hint">نام کاربری، رمز پنل و کد الگو در پیشخوان (صفحه‌ی «پیامک → تنظیمات») پر می‌شود؛ اینجا فقط قالب را انتخاب و ارسال کنید.</p>';
		NPT_SMS::render_send();
		NPT_SMS::render_report();
	}

	private static function tab_quick() {
		$s = NPT_Bar::settings();
		?>
		<form class="nptp-quick" method="post" action="<?php echo esc_url( self::panel_url() ); ?>">
			<?php wp_nonce_field( self::NONCE . '_quick' ); ?>
			<input type="hidden" name="npt_panel_form" value="quick">
			<input type="hidden" name="npt_tab" value="quick">
			<div class="nptp-box">
				<h3>راهم‌های ارتباطی</h3>
				<label class="nptp-check"><input type="hidden" name="npt_bar_settings[enable_call]" value="0"><input type="checkbox" name="npt_bar_settings[enable_call]" value="1" <?php checked( $s['enable_call'], 1 ); ?>> تماس تلفنی فعال باشد</label>
				<label>شماره تماس<input type="tel" name="npt_bar_settings[call_number]" value="<?php echo esc_attr( $s['call_number'] ); ?>" dir="ltr"></label>
				<label>عنوان تماس<input type="text" name="npt_bar_settings[call_label]" value="<?php echo esc_attr( $s['call_label'] ); ?>"></label>
				<label class="nptp-check"><input type="hidden" name="npt_bar_settings[enable_whatsapp]" value="0"><input type="checkbox" name="npt_bar_settings[enable_whatsapp]" value="1" <?php checked( $s['enable_whatsapp'], 1 ); ?>> واتس‌اپ فعال باشد</label>
				<label>شماره واتس‌اپ (با کد کشور)<input type="tel" name="npt_bar_settings[whatsapp_number]" value="<?php echo esc_attr( $s['whatsapp_number'] ); ?>" dir="ltr"></label>
				<label>عنوان واتس‌اپ<input type="text" name="npt_bar_settings[whatsapp_label]" value="<?php echo esc_attr( $s['whatsapp_label'] ); ?>"></label>
				<label class="nptp-check"><input type="hidden" name="npt_bar_settings[enable_telegram]" value="0"><input type="checkbox" name="npt_bar_settings[enable_telegram]" value="1" <?php checked( $s['enable_telegram'], 1 ); ?>> تلگرام فعال باشد</label>
				<label>نشانی تلگرام<input type="url" name="npt_bar_settings[telegram_url]" value="<?php echo esc_attr( $s['telegram_url'] ); ?>" dir="ltr"></label>
				<label>عنوان تلگرام<input type="text" name="npt_bar_settings[telegram_label]" value="<?php echo esc_attr( $s['telegram_label'] ); ?>"></label>
			</div>
			<div class="nptp-box">
				<h3>متن پنجره ارتباطی</h3>
				<label>عنوان<input type="text" name="npt_bar_settings[popup_title]" value="<?php echo esc_attr( $s['popup_title'] ); ?>"></label>
				<label>زیرعنوان<input type="text" name="npt_bar_settings[popup_subtitle]" value="<?php echo esc_attr( $s['popup_subtitle'] ); ?>"></label>
				<label class="nptp-check"><input type="hidden" name="npt_bar_settings[enable_custom]" value="0"><input type="checkbox" name="npt_bar_settings[enable_custom]" value="1" <?php checked( $s['enable_custom'], 1 ); ?>> لینک‌های سفارشی نمایش داده شود</label>
			</div>
			<button type="submit" class="nptp-btn">ذخیره تغییرات</button>
			<p class="nptp-hint">رنگ‌ها، لوگو، واحد قیمت و تنظیمات PDF فقط در پیشخوان قابل تغییر است.</p>
		</form>
		<?php
	}
}
