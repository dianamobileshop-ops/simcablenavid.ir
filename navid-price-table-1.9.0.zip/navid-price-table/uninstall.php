<?php
/**
 * Fires only when the plugin is deleted from wp-admin (not on simple
 * deactivation), so it's safe to remove everything the plugin created.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// --- Options -------------------------------------------------------
// Captured before the option list is deleted: they hold the IDs of the pages
// this plugin created by itself.
$panel_page_id    = (int) get_option( 'npt_panel_page', 0 );
$register_page_id = (int) get_option( 'npt_register_page', 0 );

$delete_data = (bool) get_option( 'npt_delete_data', false );

$options = array(
	'npt_edit_capability',
	'npt_phone',
	'npt_address',
	'npt_seo_heading',
	'npt_seo_heading_tag',
	'npt_seo_intro',
	'npt_enable_schema',
	'npt_table_cache_v',
	'npt_adjust_percent',
	'npt_header_title',
	'npt_header_show_month',
	'npt_header_show_date',
	'npt_unit_sentence',
	'npt_logo_id',
	'npt_mark1_id',
	'npt_mark2_id',
	'npt_mark3_id',
	'npt_header_color',
	'npt_accent_color',
	'npt_pdf_font',
	'npt_currency_unit',
	'npt_online_size_format',
	'npt_footer_domain',
	'npt_show_globe',
	'npt_telegram',
	'npt_instagram',
	'npt_meter_badge_enable',
	'npt_meter_sentence',
	'npt_globe_id',
	'npt_telegram_icon_id',
	'npt_instagram_icon_id',
	'npt_proforma_seq',
	'npt_price_backup',
	'npt_notify_push',
	'npt_notify_sms',
	'npt_notify_mobiles',
	'npt_push_keys',
	'npt_push_subs',
	'npt_push_last',
	'npt_delete_data',
	'npt_proforma_db_ver',
	'npt_sms_username',
	'npt_sms_password',
	'npt_sms_from',
	'npt_sms_db_ver',
	'npt_sms_otp_pattern',
	'npt_sms_otp_params',
	// Merged Mobile Quick Bar. 'mqb_settings' is the legacy plugin's own option
	// and is only removed here because this plugin took over its job; if the
	// standalone plugin is re-installed later it simply starts from defaults.
	'npt_bar_settings',
	'npt_bar_imported',
	'npt_panel_page',
	'npt_panel_ver',
	'npt_register_page',
);
foreach ( $options as $option ) {
	delete_option( $option );
}
delete_option( 'mqb_settings' );

// --- Roles, capabilities and the auto-created panel / register pages -------
remove_role( 'npt_business_manager' );
foreach ( array( 'administrator', 'shop_manager', 'editor' ) as $role_slug ) {
	$role = get_role( $role_slug );
	if ( $role ) {
		$role->remove_cap( 'npt_manage_panel' );
	}
}

foreach ( array( $panel_page_id, $register_page_id ) as $page_id ) {
	if ( $page_id && 'page' === get_post_type( $page_id ) ) {
		wp_delete_post( $page_id, true );
	}
}

// --- Custom tables (proforma archive + SMS contacts/log) ------------
// Customer and contact data is dropped only when the owner opted in on the
// settings page (captured before the option list was deleted above).
global $wpdb;

$tables = array(
	$wpdb->prefix . 'npt_proformas',
	$wpdb->prefix . 'npt_proforma_customers',
	$wpdb->prefix . 'npt_sms_log',
	$wpdb->prefix . 'npt_sms_contacts',
);
foreach ( $delete_data ? $tables : array() as $table ) {
	// Identifiers cannot use prepare() placeholders pre-6.2; backtick-escape instead.
	$safe_table = '`' . str_replace( '`', '', $table ) . '`';
	$wpdb->query( "DROP TABLE IF EXISTS {$safe_table}" ); // phpcs:ignore
}

// --- Cached files (font cache + generated PDFs) under uploads -------
require_once ABSPATH . 'wp-admin/includes/file.php';
WP_Filesystem();
global $wp_filesystem;

$upload_dir = wp_upload_dir();
$dirs       = array(
	trailingslashit( $upload_dir['basedir'] ) . 'npt-fonts',
	trailingslashit( $upload_dir['basedir'] ) . 'npt-pdf-cache',
);
// Server-side backups hold customer data, so they follow the same opt-in as the tables.
if ( $delete_data ) {
	$dirs[] = trailingslashit( $upload_dir['basedir'] ) . 'npt-backups';
}

foreach ( $dirs as $dir ) {
	if ( $wp_filesystem && $wp_filesystem->is_dir( $dir ) ) {
		$wp_filesystem->delete( $dir, true );
	}
}

// --- Leftover transients (rate-limit counters expire on their own, but
// clean up anything still sitting around) --------------------------
$wpdb->query( // phpcs:ignore
	"DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_npt\_%' OR option_name LIKE '_transient_timeout_npt\_%'"
);
